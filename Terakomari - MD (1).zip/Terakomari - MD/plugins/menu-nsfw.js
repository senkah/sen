let handler = async (m) => {
  m.reply(`
╭─────『 Menu NSFW 』
ᯓ .hentai Ⓟ
ᯓ .nhentaidl <code> Ⓟ
ᯓ .paptt Ⓟ
ᯓ .genshin Ⓟ
ᯓ .swimsuit Ⓟ
ᯓ .schoolswimsuit Ⓟ
ᯓ .white Ⓟ
ᯓ .barefoot Ⓟ
ᯓ .touhou Ⓟ
ᯓ .gamecg Ⓟ
ᯓ .hololive Ⓟ
ᯓ .uncensored Ⓟ
ᯓ .sunglasses Ⓟ
ᯓ .glasses Ⓟ
ᯓ .weapon Ⓟ
ᯓ .shirtlift Ⓟ
ᯓ .chain Ⓟ
ᯓ .fingering Ⓟ
ᯓ .flatchest Ⓟ
ᯓ .torncloth Ⓟ
ᯓ .bondage Ⓟ
ᯓ .demon Ⓟ
ᯓ .wet Ⓟ
ᯓ .pantypull Ⓟ
ᯓ .headdress Ⓟ
ᯓ .headphone Ⓟ
ᯓ .tie Ⓟ
ᯓ .anusview Ⓟ
ᯓ .shorts Ⓟ
ᯓ .stokings Ⓟ
ᯓ .topless Ⓟ
ᯓ .beach Ⓟ
ᯓ .bunnygirl Ⓟ
ᯓ .bunnyear Ⓟ
ᯓ .idol Ⓟ
ᯓ .vampire Ⓟ
ᯓ .gun Ⓟ
ᯓ .maid Ⓟ
ᯓ .bra Ⓟ
ᯓ .nobra Ⓟ
ᯓ .bikini Ⓟ
ᯓ .whitehair Ⓟ
ᯓ .blonde Ⓟ
ᯓ .pinkhair Ⓟ
ᯓ .bed Ⓟ
ᯓ .ponytail Ⓟ
ᯓ .nude Ⓟ
ᯓ .dress Ⓟ
ᯓ .underwear Ⓟ
ᯓ .foxgirl Ⓟ
ᯓ .uniform Ⓟ
ᯓ .skirt Ⓟ
ᯓ .sex Ⓟ
ᯓ .sex2 Ⓟ
ᯓ .sex3 Ⓟ
ᯓ .breast Ⓟ
ᯓ .twintail Ⓟ
ᯓ .spreadpussy Ⓟ
ᯓ .tears Ⓟ
ᯓ .seethrough Ⓟ
ᯓ .breasthold Ⓟ
ᯓ .drunk Ⓟ
ᯓ .fateseries Ⓟ
ᯓ .spreadlegs Ⓟ
ᯓ .openshirt Ⓟ
ᯓ .headband Ⓟ
ᯓ .food Ⓟ
ᯓ .close Ⓟ
ᯓ .tree Ⓟ
ᯓ .nipples Ⓟ
ᯓ .erectnipples Ⓟ
ᯓ .horns Ⓟ
ᯓ .greenhair Ⓟ
ᯓ .wolfgirl Ⓟ
ᯓ .catgirl Ⓟ
ᯓ .rule34 Ⓟ
ᯓ .sblowjob Ⓟ
ᯓ .wecchi Ⓟ
ᯓ .wpaizuri Ⓟ
ᯓ .whentai Ⓟ Ⓛ
ᯓ .wmaid Ⓟ
ᯓ .wmilf Ⓟ
ᯓ .wneko Ⓟ Ⓛ
ᯓ .woppai Ⓟ Ⓛ
ᯓ .woral Ⓟ Ⓛ
ᯓ .nsfw Ⓟ Ⓛ
ᯓ .nsfwstiker Ⓟ Ⓛ
╰–––––––––––––––༓
  `.trim())
}
handler.command = /^menunsfw$/i
handler.help = ["menunsfw"]
handler.tags = ["main"]
export default handler