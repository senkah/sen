// RECODE BY HAIDAR (recode)
// © DanzNano (pemilik)
//JANGAN HAPUS CREDITS!! HAPUS? = GW ENC SEMUA!! 

"Yoimiya - MD" /// JANGAN DI UBAH NANTI ERROR
//𝙎𝘾 𝙄𝙉𝙄 𝙁𝙍𝙀𝙀 100% 𝙆𝘼𝙇𝙊 𝘼𝘿𝘼 𝙔𝘼𝙉𝙂 𝙉𝙂𝙀𝙅𝙐𝘼𝙇 𝘽𝙀𝙎𝙊𝙆 𝙈𝘼𝙈𝘼𝙆𝙉𝙔𝘼 𝙈𝘼𝙏𝙄


𝐑𝐎𝐎𝐌 𝐂𝐇𝐀𝐓 𝐁𝐎𝐓: 'https://chat.whatsapp.com/DcttriOn7WTFWlFBw2vCDW',
𝐂𝐇 𝐎𝐑𝐈: 'https://whatsapp.com/channel/0029VbAzkO6L7UVWEtl04S2F
//DILARANG HAPUS CREDITS 
© Haidar Rvx
#recode by haidarrvx
footer '©SENN Rvx | SENN - MD'
