import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
      
global.pairingNumber = 6285602384905
global.owner = [
  ['6285783491057', 'Zen', true]
]
global.mods = []

global.namebot = 'Launcher - MD'
global.author = 'Zen'

global.wait = 'Loading...'
global.eror = 'Terjadi Kesalahan...'
global.domain= '_',
global.ptla= '_',
global.nestid= '5',
global.egg= '15',
global.loc= '1',   

global.payment = {
  dana: "089xxxxxxxx",
  ovo: "089xxxxxxxx",
  gopay: "089xxxxxxxx",
  bca: "123456789 - A/N Store",
  bri: "123456789 - A/N Store",
  mandiri: "123456789 - A/N Store"
}

global.pakasir = {
slug: 'kilersbotz',
apikey: 'bWDO2M8GcfruzXscdKNQJC3vw8Y8PV13',
expired: 30 //1 = 1menit. 30 = 30menit
}

global.stickpack = 'Croted By'
global.stickauth = namebot

global.multiplier = 38 // The higher, The harder levelup

/*============== EMOJI ==============*/
global.rpg = {
  emoticon(string) {
    string = string.toLowerCase()
    let emot = {
      level: '📊',
      limit: '🎫',
      health: '❤️',
      stamina: '🔋',
      exp: '✨',
      money: '💹',
      bank: '🏦',
      potion: '🥤',
      diamond: '💎',
      common: '📦',
      uncommon: '🛍️',
      mythic: '🎁',
      legendary: '🗃️',
      superior: '💼',
      pet: '🔖',
      trash: '🗑',
      armor: '🥼',
      sword: '⚔️',
      pickaxe: '⛏️',
      fishingrod: '🎣',
      wood: '🪵',
      rock: '🪨',
      string: '🕸️',
      horse: '🐴',
      cat: '🐱',
      dog: '🐶',
      fox: '🦊',
      petFood: '🍖',
      iron: '⛓️',
      gold: '🪙',
      emerald: '❇️',
      upgrader: '🧰'
      
    }
    let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
    if (!results.length) return ''
    else return emot[results[0][0]]
  }
}

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})
