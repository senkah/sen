
let potion = 70000;
let Hbpotion = potion.toLocaleString();

let Spotion = 2000;
let Hspotion = Spotion.toLocaleString();

let Bdiamond = 1000000;
let Hbdiamond = Bdiamond.toLocaleString();

let Sdiamond = 10000;
let Hsdiamond = Sdiamond.toLocaleString();

let Broket = 250000000;
let Hbroket = Broket.toLocaleString();

let Baero = 100000;
let Hbaero = Baero.toLocaleString();

let Saero = 30000;
let Hsaero = Saero.toLocaleString();

let Bcommon = 600000;
let Hbcommon = Bcommon.toLocaleString();

let Bcoal = 45000;
let Hbcoal = Bcoal.toLocaleString();

let Scoal = 12000;
let Hscoal = Scoal.toLocaleString();

let Scommon = 8000;
let Hscommon = Scommon.toLocaleString();

let Suncommon = 3200;
let Hsuncommon = Suncommon.toLocaleString();

let Buncommon = 800000;
let Hbuncommon = Buncommon.toLocaleString();

let Bmythic = 4000000;
let Hbmythic = Bmythic.toLocaleString();

let Smythic = 4000;
let Hsmythic = Smythic.toLocaleString();

let Blegendary = 8000000;
let Hblegendary = Blegendary.toLocaleString();

let Slegendary = 50000;
let Hslegendary = Slegendary.toLocaleString();

let Bsampah = 12200;
let Hbsampah = Bsampah.toLocaleString();

let Ssampah = 592;
let Hssampah = Ssampah.toLocaleString();

let Bkayu = 120000;
let Hbkayu = Bkayu.toLocaleString();

let Skayu = 4300;
let Hskayu = Skayu.toLocaleString();

let Bbotol = 10000;
let Hbbotol = Bbotol.toLocaleString();

let Sbotol = 5000;
let Hsbotol = Sbotol.toLocaleString();

let Bkaleng = 40000;
let Hbkaleng = Bkaleng.toLocaleString();

let Skaleng = 8000;
let Hskaleng = Skaleng.toLocaleString();

let Bkardus = 40000;
let Hbkardus = Bkardus.toLocaleString();

let Skardus = 5000;
let Hskardus = Skardus.toLocaleString();

let Bpelastik = 60000;
let Hbpelastik = Bpelastik.toLocaleString();

let Spelastik = 7000;
let Hspelastik = Spelastik.toLocaleString();

let Bpisang = 55000;
let Hbpisang = Bpisang.toLocaleString();

let Spisang = 1000;
let Hspisang = Spisang.toLocaleString();

let Bmangga = 46000;
let Hbmangga = Bmangga.toLocaleString();

let Smangga = 1500;
let Hsmangga = Smangga.toLocaleString();

let Bjeruk = 60000;
let Hbjeruk = Bjeruk.toLocaleString();

let Sjeruk = 3000;
let Hsjeruk = Sjeruk.toLocaleString();

let Banggur = 55000;
let Hbanggur = Banggur.toLocaleString();

let Sanggur = 1500;
let Hsanggur = Sanggur.toLocaleString();

let Bapel = 55000;
let Hbapel = Bapel.toLocaleString();

let Sapel = 4000;
let Hsapel = Sapel.toLocaleString();

let Skulit = 2000;
let Hskulit = Sapel.toLocaleString();

let Bkulit = 68000;
let Hbkulit = Sapel.toLocaleString();

let Bbibitpisang = 5500;
let Hbbibitpisang = Bbibitpisang.toLocaleString();

let Sbibitpisang = 500;
let Hsbibitpisang = Sbibitpisang.toLocaleString();

let Bbibitmangga = 5500;
let Hbbibitmangga = Bbibitmangga.toLocaleString();

let Sbibitmangga = 500;
let Hsbibitmangga = Sbibitmangga.toLocaleString();

let Bbibitjeruk = 5500;
let Hbbibitjeruk = Bbibitjeruk.toLocaleString();

let Sbibitjeruk = 500;
let Hsbibitjeruk = Sbibitjeruk.toLocaleString();

let Bbibitanggur = 5500;
let Hbbibitanggur = Bbibitanggur.toLocaleString();

let Sbibitanggur = 500;
let Hsbibitanggur = Sbibitanggur.toLocaleString();

let Bbibitapel = 5500;
let Hbbibitapel = Bbibitapel.toLocaleString();

let Sbibitapel = 500;
let Hsbibitapel = Sbibitapel.toLocaleString();

let Bgardenboxs = 950000;
let Hbgardenboxs = Bgardenboxs.toLocaleString();

let Sgardenboc = 350000;
let Hsgardenboc = Sgardenboc.toLocaleString();

let Bberlian = 1500000;
let Hbberlian = Bberlian.toLocaleString();

let Sberlian = 10000;
let Hsberlian = Sberlian.toLocaleString();

let Bemasbatang = 1000000;
let Hbemasbatang = Bemasbatang.toLocaleString();

let Semasbatang = 10000;
let Hsemasbatang = Semasbatang.toLocaleString();

let Bemasbiasa = 1000000;
let Hbemasbiasa = Bemasbiasa.toLocaleString();

let Semasbiasa = 15000;
let Hsemasbiasa = Semasbiasa.toLocaleString();

let Bphonix = 1000000000;
let Hbphonix = Bphonix.toLocaleString();

let Sphonix = 1000000;
let Hsphonix = Sphonix.toLocaleString();

let Bgriffin = 100000000;
let Hbgriffin = Bgriffin.toLocaleString();

let Sgriffin = 100000;
let Hsgriffin = Sgriffin.toLocaleString();

let Bkyubi = 100000000;
let Hbkyubi = Bkyubi.toLocaleString();

let Skyubi = 100000;
let Hskyubi = Skyubi.toLocaleString();

let Bnaga = 100000000;
let Hbnaga = Bnaga.toLocaleString();

let Snaga = 100000;
let Hsnaga = Snaga.toLocaleString();

let Bcentaur = 100000000;
let Hbcentaur = Bcentaur.toLocaleString();

let Scentaur = 100000;
let Hscentaur = Scentaur.toLocaleString();

let Bkuda = 50000000;
let Hbkuda = Bkuda.toLocaleString();

let Skuda = 100000;
let Hskuda = Skuda.toLocaleString();

let Brubah = 100000000;
let Hbrubah = Brubah.toLocaleString();

let Srubah = 100000;
let Hsrubah = Srubah.toLocaleString();

let Bkucing = 5000000;
let Hbkucing = Bkucing.toLocaleString();

let Skucing = 50000;
let Hskucing = Skucing.toLocaleString();

let Bserigala = 50000000;
let Hbserigala = Bserigala.toLocaleString();

let Sserigala = 500000;
let Hsserigala = Sserigala.toLocaleString();

let Bmakananpet = 50000;
let Hbmakananpet = Bmakananpet.toLocaleString();

let Smakananpet = 500;
let Hsmakananpet = Smakananpet.toLocaleString();

let Bmakananphonix = 80000;
let Hbmakananphonix = Bmakananphonix.toLocaleString();

let Smakananphonix = 5000;
let Hsmakananphonix = Smakananphonix.toLocaleString();

let Bmakanangriffin = 80000;
let Hbmakanangriffin = Bmakanangriffin.toLocaleString();

let Smakanangriffin = 5000;
let Hsmakanangriffin = Smakanangriffin.toLocaleString();

let Bmakanannaga = 150000;
let Hbmakanannaga = Bmakanannaga.toLocaleString();

let Smakanannaga = 10000;
let Hsmakanannaga = Smakanannaga.toLocaleString();

let Bmakanankyubi = 150000;
let Hbmakanankyubi = Bmakanankyubi.toLocaleString();

let Smakanankyubi = 10000;
let Hsmakanankyubi = Smakanankyubi.toLocaleString();

let Bmakanancentaur = 150000;
let Hbmakanancentaur = Bmakanancentaur.toLocaleString();

let Smakanancentaur = 10000;
let Hsmakanancentaur = Smakanancentaur.toLocaleString();

let Bhealtmonster = 20000;
let Hbhealtmonster = Bhealtmonster.toLocaleString();

let Bpet = 1500000;
let Hbpet = Bpet.toLocaleString();

let Spet = 1000;
let Hspet = Spet.toLocaleString();

let Blimit = 60000;
let Hblimit = Blimit.toLocaleString();

let Slimit = 10000;
let Hslimit = Slimit.toLocaleString();

let Bexp = 550;
let Hbexp = Bexp.toLocaleString();

let Baqua = 5000;
let Hbaqua = Baqua.toLocaleString();

let Saqua = 1000;
let Hsaqua = Saqua.toLocaleString();

let Biron = 60000;
let Hbiron = Biron.toLocaleString();

let Siron = 5000;
let Hsiron = Siron.toLocaleString();

let Bstring = 40000;
let Hbstring = Bstring.toLocaleString();

let Sstring = 5000;
let Hsstring = Sstring.toLocaleString();

let Bumpan = 12000;
let Hbumpan = Bumpan.toLocaleString();

let Sumpan = 1000;
let Hsumpan = Sumpan.toLocaleString();

let Bpancingan = 5000000;
let Hbpancingan = Bpancingan.toLocaleString();

let Bsniper = 5999999;
let Hbsniper = Bsniper.toLocaleString();

let Bpeluru = 30000;
let Hbpeluru = Bpeluru.toLocaleString();

let Speluru = 2599;
let Hspeluru = Speluru.toLocaleString();

let Bbatu = 5000;
let Hbbatu = Bbatu.toLocaleString();

let Sbatu = 500;
let Hsbatu = Sbatu.toLocaleString();

let Bketake = 15;
let Hbketake = Bketake.toLocaleString();

let Btiketcoin = 500;
let Hbtiketcoin = Btiketcoin.toLocaleString();

let Bkoinexpg = 500000;
let Hbkoinexpg = Bkoinexpg.toLocaleString();

let Beleksirb = 500;
let Hbeleksirb = Beleksirb.toLocaleString();

let handler  = async (m, { conn, command, args, usedPrefix, owner }) => {
    let _armor = global.db.data.users[m.sender].armor
    let Bharmor = (_armor == 0 ? 500000 : '' || _armor == 1 ? 1500000 : '' || _armor == 2 ? 3000000 : '' || _armor == 3 ? 6500000 : '' || _armor == 4 ? 8500000 : '' || _armor == 5 ? 17000000 : '' || _armor == 6 ? 24000000 : '' || _armor == 7 ? 40000000 : '' || _armor == 8 ? 70000000 : '' || _armor == 9 ? 160000000 : '' || _armor == 10 ? 320000000 : '' || _armor == 11 ? 600000000 : '' || _armor == 12 ? 800000000 : '' || _armor == 13 ? 1000000000 : '' || _armor == 14 ? 1500000000 : '' || _armor == 15 ? 3000000000 : '' || _armor == 16 ? 5000000000 : '' || _armor == 17 ? 7000000000 : '' || _armor == 18 ? 9000000000 : '' || _armor == 19 ? 14000000000 : '' || _armor == 20 ? 'Level Max' : '');
    let _Bsword = global.db.data.users[m.sender].sword
    let Bsword = (_Bsword == 0 ? 300000 : '' || _Bsword == 1 ? 550000 : '' || _Bsword == 2 ? 850000 : '' || _Bsword == 3 ? 1200000 : '' || _Bsword == 4 ? 2400000 : '' || _Bsword == 5 ? 999999 : '' || _Bsword == 6 ? 1499999 : '' || _Bsword == 7 ? 4000000 : '' || _Bsword == 8 ? 6500000 : '' || _Bsword == 9 ? 2999999 : '' || _Bsword == 10 ? 3999999 : '' || _Bsword == 11 ? 8000000 : '' || _Bsword == 12 ? 13000000 : '' || _Bsword == 13 ? 16000000 : '' || _Bsword == 14 ? 19000000 : '' || _Bsword == 15 ? 21000000 : '' || _Bsword == 16 ? 25000000 : '' || _Bsword == 17 ? 28000000 : '' || _Bsword == 18 ? 33000000 : '' || _Bsword == 19 ? 38000000 : '' || _Bsword == 20 ? 45000000 : '' || _Bsword == 21 ? 57000000 : '' || _Bsword == 22 ? 70000000 : '' || _Bsword == 23 ? 100000000 : '' || _Bsword == 24 ? 230000000 : '' || _Bsword == 25 ? 430000000 : '' || _Bsword == 26 ? 650000000 : '' || _Bsword == 27 ? 800000000 : '' || _Bsword == 28 ? 1500000000 : '' || _Bsword == 29 ? 3500000000 : '' || _Bsword == 30 ? 'Level MAX' : '');
    let Harmor = Bharmor.toLocaleString()
    let Hbsword = Bsword.toLocaleString()
    let armorsukses = (_armor == 0 ? '✅ Suksess Membeli Armor Seharga ' + Harmor + ', Cek Level Armormu\n*Ketik:* .listarmor' : '⬆️ Sukses Upgrade Armor Seharga ' + Harmor + ', Cek Level Armormu\n*Ketik:* .listarmor')
    let anomoney = (_armor == 0 ? 'Uang Mu Tidak Cukup Untuk Membeli Armor Seharga ' + Harmor : 'Gagal Upgrade Armor, Karna Uangmu tidak Cukup, Harga Upgrade: ' + Harmor)
    let swordsukses = (_Bsword == 0 ? '✅ Suksess Membeli Sword Seharga ' + Hbsword + ', Cek Level Swordmu\n*Ketik:* .listsword' : '⬆️ Sukses Upgrade Sword Seharga ' + Hbsword + ', Cek Level Swordmu\n*Ketik:* .listsword')
    let snomoney = (_Bsword == 0 ? 'Uang Mu Tidak Cukup Untuk Membeli Sword Seharga ' + Hbsword : 'Gagal Upgrade Sword, Karna Uangmu tidak Cukup, Harga Upgrade: ' + Hbsword)
    let type = (args[0] || '').toLowerCase()
    let _type = (args[1] || '').toLowerCase()
    let jualbeli = (args[0] || '').toLowerCase()
    let nomors = m.sender
    let money = global.db.data.users[m.sender].money
    const Kchat = `
ᴘᴇɴɢɢᴜɴᴀᴀɴ ${usedPrefix}sʜᴏᴘ <ʙᴜʏ|sᴇʟʟ> <ɪᴛᴇᴍ> <ᴊᴜᴍʟᴀʜ>
ᴄᴏɴᴛᴏʜ ᴘᴇɴɢɢᴜɴᴀᴀɴ: *${usedPrefix}sʜᴏᴘ ʙᴜʏ ᴘᴏᴛɪᴏɴ 1*

_ᴜᴀɴɢ ʏᴀɴɢ ᴀɴᴅᴀ ᴍɪʟɪᴋɪ :_
*💸 ʀᴘ.${money}*

▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
_*ᴋᴇʙᴜᴛᴜʜᴀɴ   |   ʜᴀʀɢᴀ ʙᴇʟɪ*_
💳 ʟɪᴍɪᴛ:       ${Hblimit}
🎟️ ᴛɪᴋᴇᴛᴍ:       ${Hbhealtmonster}
🎫 ᴋᴜᴘᴏɴ:       ${Hbtiketcoin}
🪙 ᴋᴏɪɴᴇxᴘɢ:       ${Hbkoinexpg}

_*ᴋᴇʙᴜᴛᴜʜᴀɴ   |   ʜᴀʀɢᴀ ᴊᴜᴀʟ*_
💳 ʟɪᴍɪᴛ:       ${Hslimit}
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
_*ʙɪʙɪᴛ ʙᴜᴀʜ   |   ʜᴀʀɢᴀ ʙᴇʟɪ*_
🍌 ʙɪʙɪᴛ ᴘɪsᴀɴɢ:       ${Hbbibitpisang}
🍇 ʙɪʙɪᴛ ᴀɴɢɢᴜʀ:       ${Hbbibitanggur}
🥭 ʙɪʙɪᴛ ᴍᴀɴɢɢᴀ:       ${Hbbibitmangga}
🍊 ʙɪʙɪᴛ ᴊᴇʀᴜᴋ:       ${Hbbibitjeruk}
🍎 ʙɪʙɪᴛ ᴀᴘᴇʟ:       ${Hbbibitapel}
📦 ɢᴀʀᴅᴇɴʙᴏx:       ${Hbgardenboxs}
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
_*ʙᴀʀᴀɴɢ   |   ʜᴀʀɢᴀ ʙᴇʟɪ*_
🥤 ᴘᴏᴛɪᴏɴ:       ${Hbpotion}
💎 ᴅɪᴀᴍᴏɴᴅ:       ${Hbdiamond}
🪵 ᴄᴏᴀʟ:       ${Hbcoal}
🗑️ sᴀᴍᴘᴀʜ:       ${Hbsampah}
🕸️ sᴛʀɪɴɢ:       ${Hbstring}
⚙️ ɪʀᴏɴ:       ${Hbiron}
🪨 ʙᴀᴛᴜ:       ${Hbbatu}
🍶 ʙᴏᴛᴏʟ:       ${Hbbotol}
🗑️ ᴋᴀʟᴇɴɢ:       ${Hbkaleng}
📦 ᴋᴀʀᴅᴜs:       ${Hbkardus}
🥡 ᴘʟᴀsᴛɪᴋ:       ${Hbpelastik}
🪵 ᴋᴀʏᴜ:       ${Hbkayu}
💍 ʙᴇʀʟɪᴀɴ:       ${Hbberlian}
🪙 ᴇᴍᴀs:       ${Hbemasbiasa}
🧣 ᴋᴜʟɪᴛ:      ${Hbkulit}
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
ʙᴀʀᴀɴɢ   |   ʜᴀʀɢᴀ ᴊᴜᴀʟ
🥤 ᴘᴏᴛɪᴏɴ:       ${Hspotion}
💎 ᴅɪᴀᴍᴏɴᴅ:       ${Hsdiamond}
🪵 ᴄᴏᴀʟ:       ${Hscoal}
🗑️ sᴀᴍᴘᴀʜ:       ${Hssampah}
🕸️ sᴛʀɪɴɢ:       ${Hsstring}
⚙️ ɪʀᴏɴ:       ${Hsiron}
🪵 ʙᴀᴛᴜ:       ${Hsbatu}
🍶 ʙᴏᴛᴏʟ:       ${Hsbotol}
🗑️ ᴋᴀʟᴇɴɢ:       ${Hskaleng}
📦 ᴋᴀʀᴅᴜs:       ${Hskardus}
🥡 ᴘʟᴀsᴛɪᴋ:       ${Hspelastik}
🪙 ᴋᴀʏᴜ:       ${Hskayu}
💍 ʙᴇʀʟɪᴀɴ:       ${Hsberlian}
🪙 ᴇᴍᴀs:       ${Hsemasbiasa}
🧣 ʟᴇᴀᴛʜᴇʀ:       ${Hskulit}
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
ᴄʜᴇsᴛ | ʜᴀʀɢᴀ ʙᴇʟɪ
📦 ᴘᴇᴛ:       ${Hbpet}
📦 ᴜɴᴄᴏᴍᴍᴏɴ:       ${Hbuncommon}
👑 ᴍʏᴛʜɪᴄ:       ${Hbmythic}
💎 ʟᴇɢᴇɴᴅᴀʀʏ:       ${Hblegendary}
📦 ᴄᴏᴍᴍᴏɴ:       ${Hbcommon}
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
ᴄʜᴇsᴛ | ʜᴀʀɢᴀ ᴊᴜᴀʟ
📦 ᴘᴇᴛ:       ${Hspet}
📦 ᴜɴᴄᴏᴍᴍᴏɴ:       ${Hsuncommon}
👑 ᴍʏᴛʜɪᴄ:       ${Hsmythic}
💎 ʟᴇɢᴇɴᴅᴀʀʏ:       ${Hslegendary}
📦 ᴄᴏᴍᴍᴏɴ:       ${Hscommon}
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
ʙᴜᴀʜ | ʜᴀʀɢᴀ ʙᴇʟɪ
🍌 ᴘɪsᴀɴɢ:       ${Hbpisang}
🍇 ᴀɴɢɢᴜʀ:       ${Hbanggur}
🥭 ᴍᴀɴɢɢᴀ:       ${Hbmangga}
🍊 ᴊᴇʀᴜᴋ:       ${Hbjeruk}
🍎 ᴀᴘᴇʟ:       ${Hbapel}
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
ʙᴜᴀʜ | ʜᴀʀɢᴀ ᴊᴜᴀʟ
🍌 ᴘɪsᴀɴɢ:       ${Hspisang}
🍇 ᴀɴɢɢᴜʀ:       ${Hsanggur}
🥭 ᴍᴀɴɢɢᴀ:       ${Hsmangga}
🍊 ᴊᴇʀᴜᴋ:       ${Hsjeruk}
🍎 ᴀᴘᴇʟ:       ${Hsapel}
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
ᴍɪɴᴜᴍᴀɴ | ʜᴀʀɢᴀ ʙᴇʟɪ
🥤 ᴀǫᴜᴀ:       ${Hbaqua}

ᴍɪɴᴜᴍᴀɴ | ʜᴀʀɢᴀ ᴊᴜᴀʟ
🥤 ᴀǫᴜᴀ:       ${Hsaqua}
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
ғɪsʜɪɴɢ | ʜᴀʀɢᴀ ʙᴇʟɪ
🎣 ᴘᴀɴᴄɪɴɢᴀɴ:       ${Hbpancingan}
🍚 ᴜᴍᴘᴀɴ:       ${Hbumpan}
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
ᴇǫᴜɪᴘᴍᴇɴᴛ | ʜᴀʀɢᴀ ʙᴇʟɪ
🧥 ᴀʀᴍᴏʀ:       ${Harmor}
⚔️ sᴡᴏʀᴅ:       ${Hbsword}
🦯 sɴɪᴘᴇʀ:       ${Hbsniper}
🖍️ ᴘᴇʟᴜʀᴜ:       ${Hbpeluru}
🚀 ʀᴏᴋᴇᴛ:       ${Hbroket}
🛢️ ᴀᴇʀᴏᴢɪɴᴇ:       ${Hbaero}

ᴇǫᴜɪᴘᴍᴇɴᴛ | ʜᴀʀɢᴀ ᴊᴜᴀʟ
🖍️ ᴘᴇʟᴜʀᴜ:      ${Hspeluru}
🛢️ ᴀᴇʀᴏᴢɪɴᴇ:       ${Hsaero}
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
ᴘᴇʟɪʜᴀʀᴀᴀɴ | ʜᴀʀɢᴀ ʙᴇʟɪ
🐶 ᴘᴇᴛ:       ${Hbpet}
🐈 ᴋᴜᴄɪɴɢ:       ${Hbkucing}
🐎 ᴋᴜᴅᴀ:       ${Hbkuda}
🐉 ɴᴀɢᴀ:       ${Hbnaga}
🦊 ᴋʏᴜʙɪ:       ${Hbkyubi}
🦖 ᴄᴇɴᴛᴀᴜʀ:       ${Hbcentaur}
🦊 ʀᴜʙᴀʜ:       ${Hbrubah}
🕊️ ᴘʜᴏᴇɴɪx:       ${Hbphonix}
🦅 ɢʀɪғғɪɴ:       ${Hbgriffin}
🐺 sᴇʀɪɢᴀʟᴀ:       ${Hbserigala}
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
ᴘᴇʟɪʜᴀʀᴀᴀɴ | ʜᴀʀɢᴀ ᴊᴜᴀʟ
> ʙᴇʟɪ ʜᴇᴡᴀɴ ᴅɪ !sʜᴏᴘᴘᴇᴛ
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
ᴍᴀᴋᴀɴᴀɴ ᴘᴇᴛ | ʜᴀʀɢᴀ ᴊᴜᴀʟ
📦 ᴍᴀᴋᴀɴᴀɴᴘᴇᴛ:       ${Hbmakananpet}
🐉 ᴍᴀᴋᴀɴᴀɴɴᴀɢᴀ:       ${Hbmakanannaga}
🦊 ᴍᴀᴋᴀɴᴀɴᴋʏᴜʙɪ:       ${Hbmakanankyubi}
🦅 ᴍᴀᴋᴀɴᴀɴɢʀɪғғɪɴ:       ${Hbmakanangriffin}
🕊️ ᴍᴀᴋᴀɴᴀɴᴘʜᴏɴɪx:       ${Hbmakananphonix}
🦖 ᴍᴀᴋᴀɴᴀɴᴄᴇɴᴛᴀᴜʀ:       ${Hbmakanancentaur}
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
ᴍᴀᴋᴀɴᴀɴ ᴘᴇᴛ | ʜᴀʀɢᴀ ᴊᴜᴀʟ
📦 ᴍᴀᴋᴀɴᴀɴᴘᴇᴛ:       ${Hsmakananpet}
🐉 ᴍᴀᴋᴀɴᴀɴɴᴀɢᴀ       ${Hsmakanannaga}
🦊 ᴍᴀᴋᴀɴᴀɴᴋʏᴜʙɪ:       ${Hsmakanankyubi}
🦅 ᴍᴀᴋᴀɴᴀɴɢʀɪғғɪɴ:       ${Hsmakanangriffin}
🕊️ ᴍᴀᴋᴀɴᴀɴᴘʜᴏɴɪx:       ${Hsmakananphonix}
🦖 ᴍᴀᴋᴀɴᴀɴᴄᴇɴᴛᴀᴜʀ:       ${Hsmakanancentaur}
`.trim()
    try {
        if (/shop|toko/i.test(command)) {
            const count = args[2] && args[2].length > 0 ? Math.min(999999999999999, Math.max(parseInt(args[2]), 1)) : !args[2] || args.length < 4 ? 1 :Math.min(1, count)
            const sampah = global.db.data.users[m.sender].sampah
            switch (jualbeli) {
            case 'buy':
                switch (_type) {
                    case 'potion':
                            if (global.db.data.users[m.sender].money >= potion * count) {
                                global.db.data.users[m.sender].money -= potion * count
                                global.db.data.users[m.sender].potion += count * 1
                                conn.reply(m.chat, `Succes membeli ${count} Potion dengan harga ${potion * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Potion dengan harga ${potion * count} money`,)
                        break
                        case 'leather':
                            if (global.db.data.users[m.sender].money >= Bkulit * count) {
                                global.db.data.users[m.sender].money -= Bkulit * count
                                global.db.data.users[m.sender].leather += count * 1
                                conn.reply(m.chat, `Succes membeli ${count} Leather dengan harga ${potion * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Leather dengan harga ${Bkulit * count} money`,)
                        break
                    case 'diamond':
                            if (global.db.data.users[m.sender].money >= Bdiamond * count) {
                                global.db.data.users[m.sender].diamond += count * 1
                                global.db.data.users[m.sender].money -= Bdiamond * count
                                conn.reply(m.chat, `Succes membeli ${count} Diamond dengan harga ${Bdiamond * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)
                        
                        break
                    case 'common':
                            if (global.db.data.users[m.sender].money >= Bcommon * count) {
                                global.db.data.users[m.sender].common += count * 1
                                global.db.data.users[m.sender].money -= Bcommon * count
                                conn.reply(m.chat, `Succes membeli ${count} Common crate dengan harga ${Bcommon * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Common crate dengan harga ${Bcommon * count} money\n\nBuka crate dengan ketik: *${usedPrefix}open common*`, m)
                          
                        break
                        case 'coal':
                            if (global.db.data.users[m.sender].money >= Bcoal * count) {
                                global.db.data.users[m.sender].coal += count * 1
                                global.db.data.users[m.sender].money -= Bcoal * count
                                conn.reply(m.chat, `Succes membeli ${count} Coal dengan harga ${Bcoal * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Coal dengan harga ${Bcoal * count} money*`, m)
                          
                        break
                    case 'peluru':
                            if (global.db.data.users[m.sender].money >= Bpeluru * count) {
                                global.db.data.users[m.sender].peluru += count * 1
                                global.db.data.users[m.sender].money -= Bpeluru * count
                                conn.reply(m.chat, `Succes membeli ${count} Peluru dengan harga ${Bpeluru * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Peluru dengan harga ${Bpeluru * count} money*`, m)
                          
                        break
                    case 'uncommon':
                            if (global.db.data.users[m.sender].money >= Buncommon * count) {
                                global.db.data.users[m.sender].uncommon += count * 1
                                global.db.data.users[m.sender].money -= Buncommon * count
                                conn.reply(m.chat, `Succes membeli ${count} Uncommon crate dengan harga ${Buncommon * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Uncommon crate dengan harga ${Buncommon * count} money\n\nBuka crate dengan ketik: *${usedPrefix}open uncommon*`, m)
                        
                        break
                    case 'mythic':
                            if (global.db.data.users[m.sender].money >= Bmythic * count) {
                                    global.db.data.users[m.sender].mythic += count * 1
                                global.db.data.users[m.sender].money -= Bmythic * count
                                conn.reply(m.chat, `Succes membeli ${count} Mythic crate dengan harga ${Bmythic * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Mythic crate dengan harga ${Bmythic* count} money\n\nBuka crate dengan ketik: *${usedPrefix}open mythic*`, m)
                        
                        break
                    case 'legendary':
                            if (global.db.data.users[m.sender].money >= Blegendary * count) {
                                global.db.data.users[m.sender].legendary += count * 1
                                global.db.data.users[m.sender].money -= Blegendary * count
                                conn.reply(m.chat, `Succes membeli ${count} Legendary crate dengan harga ${Blegendary * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Legendary crate dengan harga ${Blegendary * count} money\n\nBuka crate dengan ketik: *${usedPrefix}open legendary*`, m)
                        
                        break
                    case 'sampah':
                            if (global.db.data.users[m.sender].money >= Bsampah * count) {
                                global.db.data.users[m.sender].sampah += count * 1
                                global.db.data.users[m.sender].money -= Bsampah * count
                                conn.reply(m.chat, `Succes membeli ${count} Sampah dengan harga ${Bsampah * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Sampah dengan harga ${Bsampah * count} money`.trim(), m)
                        
                        break
                    case 'kaleng':
                            if (global.db.data.users[m.sender].money >= Bkaleng * count) {
                                global.db.data.users[m.sender].kaleng += count * 1
                                global.db.data.users[m.sender].money -= Bkaleng * count
                                conn.reply(m.chat, `Succes membeli ${count} Kaleng dengan harga ${Bkaleng * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Kaleng dengan harga ${Bkaleng * count} money`.trim(), m)
                        
                        break
                    case 'kardus':
                            if (global.db.data.users[m.sender].money >= Bkardus * count) {
                                global.db.data.users[m.sender].kardus += count * 1
                                global.db.data.users[m.sender].money -= Bkardus * count
                                conn.reply(m.chat, `Succes membeli ${count} Kardus dengan harga ${Bkardus * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Kardus dengan harga ${Bkardus * count} money`.trim(), m)
                        
                        break
                    case 'plastik':
                            if (global.db.data.users[m.sender].money >= Bpelastik * count) {
                                global.db.data.users[m.sender].pelastik += count * 1
                                global.db.data.users[m.sender].money -= Bpelastik * count
                                conn.reply(m.chat, `Succes membeli ${count} plastik dengan harga ${Bpelastik * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} plastik dengan harga ${Bpelastik * count} money`.trim(), m)
                            
                        break
                    case 'botol':
                            if (global.db.data.users[m.sender].money >= Bbotol * count) {
                                global.db.data.users[m.sender].botol += count * 1
                                global.db.data.users[m.sender].money -= Bbotol * count
                                conn.reply(m.chat, `Succes membeli ${count} Botol dengan harga ${Bbotol * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} botol dengan harga ${Bbotol * count} money`.trim(), m)
                        
                        break
                    case 'kayu':
                            if (global.db.data.users[m.sender].money >= Bkayu * count) {
                                global.db.data.users[m.sender].kayu += count * 1
                                global.db.data.users[m.sender].money -= Bkayu * count
                                conn.reply(m.chat, `Succes membeli ${count} Kayu dengan harga ${Bkayu * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} kayu dengan harga ${Bkayu * count} money`.trim(), m)
                        
                        break
                    case 'pisang':
                            if (global.db.data.users[m.sender].money >= Bpisang * count) {
                                global.db.data.users[m.sender].pisang += count * 1
                                global.db.data.users[m.sender].money -= Bpisang * count
                                conn.reply(m.chat, `Succes membeli ${count} Pisang dengan harga ${Bpisang * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} pisang dengan harga ${Bpisang * count} money`.trim(), m)
                        
                        break
                    case 'anggur':
                            if (global.db.data.users[m.sender].money >= Banggur * count) {
                                global.db.data.users[m.sender].anggur += count * 1
                                global.db.data.users[m.sender].money -= Banggur * count
                                conn.reply(m.chat, `Succes membeli ${count} Anggur dengan harga ${Banggur * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} anggur dengan harga ${Banggur * count} money`.trim(), m)
                        
                        break
                    case 'mangga':
                            if (global.db.data.users[m.sender].money >= Bmangga * count) {
                                global.db.data.users[m.sender].mangga += count * 1
                                global.db.data.users[m.sender].money -= Bmangga * count
                                conn.reply(m.chat, `Succes membeli ${count} Mangga dengan harga ${Bmangga * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} mangga dengan harga ${Bmangga * count} money`.trim(), m)
                        
                        break
                    case 'jeruk':
                            if (global.db.data.users[m.sender].money >= Bjeruk * count) {
                                global.db.data.users[m.sender].jeruk += count * 1
                                global.db.data.users[m.sender].money -= Bjeruk * count
                                conn.reply(m.chat, `Succes membeli ${count} Jeruk dengan harga ${Bjeruk * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} jeruk dengan harga ${Bjeruk * count} money`.trim(), m)
                        
                        break
                    case 'apel':
                            if (global.db.data.users[m.sender].money >= Bapel * count) {
                                global.db.data.users[m.sender].apel += count * 1
                                global.db.data.users[m.sender].money -= Bapel * count
                                conn.reply(m.chat, `Succes membeli ${count} Apel dengan harga ${Bapel * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} apel dengan harga ${Bapel * count} money`.trim(), m)
                        
                        break
                    case 'bibitpisang':
                            if (global.db.data.users[m.sender].money >= Bbibitpisang * count) {
                                global.db.data.users[m.sender].bibitpisang += count * 1
                                global.db.data.users[m.sender].money -= Bbibitpisang * count
                                conn.reply(m.chat, `Succes membeli ${count} Bibit Pisang dengan harga ${Bbibitpisang * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} bibit pisang dengan harga ${Bbibitpisang * count} money`.trim(), m)
                        
                        break
                    case 'bibitanggur':
                            if (global.db.data.users[m.sender].money >= Bbibitanggur * count) {
                                global.db.data.users[m.sender].bibitanggur += count * 1
                                global.db.data.users[m.sender].money -= Bbibitanggur * count
                                conn.reply(m.chat, `Succes membeli ${count} Bibit Anggur dengan harga ${Bbibitanggur * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} bibit anggur dengan harga ${Bbibitanggur * count} money`.trim(), m)
                        
                        break
                    case 'bibitmangga':
                            if (global.db.data.users[m.sender].money >= Bbibitmangga * count) {
                                global.db.data.users[m.sender].bibitmangga += count * 1
                                global.db.data.users[m.sender].money -= Bbibitmangga * count
                                conn.reply(m.chat, `Succes membeli ${count} Bibit Mangga dengan harga ${Bbibitmangga * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} bibit mangga dengan harga ${Bbibitmangga * count} money`.trim(), m)
                        
                        break
                    case 'bibitjeruk':
                            if (global.db.data.users[m.sender].money >= Bbibitjeruk * count) {
                                global.db.data.users[m.sender].bibitjeruk += count * 1
                                global.db.data.users[m.sender].money -= Bbibitjeruk * count
                                conn.reply(m.chat, `Succes membeli ${count} Bibit Jeruk dengan harga ${Bbibitjeruk * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} bibit jeruk dengan harga ${Bbibitjeruk * count} money`.trim(), m)
                        
                        break
                    case 'bibitapel':
                            if (global.db.data.users[m.sender].money >= Bbibitapel * count) {
                                global.db.data.users[m.sender].bibitapel += count * 1
                                global.db.data.users[m.sender].money -= Bbibitapel * count
                                conn.reply(m.chat, `Succes membeli ${count} Bibit Apel dengan harga ${Bbibitapel * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} bibit apel dengan harga ${Bbibitapel * count} money`.trim(), m)
                        
                        break 
                    case 'gardenboxs':
                            if (global.db.data.users[m.sender].money >= Bgardenboxs * count) {
                                global.db.data.users[m.sender].gardenboxs += count * 1
                                global.db.data.users[m.sender].money -= Bgardenboxs * count
                                conn.reply(m.chat, `Succes membeli ${count} Gardenboxs dengan harga ${Bgardenboxs * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} gardenboxs dengan harga ${Bgardenboxs * count} money`.trim(), m)
                        
                        break
                    case 'berlian':
                            if (global.db.data.users[m.sender].money >= Bberlian * count) {
                                global.db.data.users[m.sender].berlian += count * 1
                                global.db.data.users[m.sender].money -= Bberlian * count
                                conn.reply(m.chat, `Succes membeli ${count} Berlian dengan harga ${Bberlian * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} berlian dengan harga ${Bberlian * count} money`.trim(), m)
                        
                        break
                    case 'emas':
                            if (global.db.data.users[m.sender].money >= Bemasbiasa * count) {
                                global.db.data.users[m.sender].emas += count * 1
                                global.db.data.users[m.sender].money -= Bemasbiasa * count
                                conn.reply(m.chat, `Succes membeli ${count} Emas dengan harga ${Bemasbiasa * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} emas dengan harga ${Bemasbiasa * count} money`.trim(), m)
                        
                        break 
                     case 'pet':
                            if (global.db.data.users[m.sender].money >= Bpet * count) {
                                global.db.data.users[m.sender].pet += count * 1
                                global.db.data.users[m.sender].money -= Bpet * count
                                conn.reply(m.chat, `Succes membeli ${count} Pet Random dengan harga ${Bpet * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} pet random dengan harga ${Bpet * count} money`.trim(), m)
                        
                        break
                   case 'limit':
                            if (global.db.data.users[m.sender].money >= Blimit * count) {
                                global.db.data.users[m.sender].limit += count * 1
                                global.db.data.users[m.sender].money -= Blimit * count
                                conn.reply(m.chat, `Succes membeli ${count} Limit dengan harga ${Blimit * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} limit dengan harga ${Blimit * count} money`.trim(), m)
                        
                        break 
                   /*case 'exp':
                            if (global.db.data.users[m.sender].money >= Bexp * count) {
                                global.db.data.users[m.sender].exp += count * 1
                                global.db.data.users[m.sender].money -= Bexp * count
                                conn.reply(m.chat, `Succes membeli ${count} Exp dengan harga ${Bexp * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} exp dengan harga ${Bexp * count} money`.trim(), m)
                        
                        break
                     case 'eleksirb':
                            if (global.db.data.users[m.sender].money >= Beleksirb * count) {
                                global.db.data.users[m.sender].eleksirb += count * 1
                                global.db.data.users[m.sender].money -= Beleksirb * count
                                conn.reply(m.chat, `Succes membeli ${count} Eleksir Biru dengan harga ${Beleksirb * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Eleksir Biru dengan harga ${Beleksirb * count} money`.trim(), m)
                        
                        break
                        case 'koinexpg':
                            if (global.db.data.users[m.sender].money >= Bkoinexpg * count) {
                                global.db.data.users[m.sender].koinexpg += count * 1
                                global.db.data.users[m.sender].money -= Bkoinexpg * count
                                conn.reply(m.chat, `Succes membeli ${count} Koinexpg dengan harga ${Bkoinexpg * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} koinexpg dengan harga ${Bkoinexpg * count} money`.trim(), m)
                        
                        break*/
                  case 'cupon':
                            if (global.db.data.users[m.sender].tiketcoin >= Btiketcoin * count) {
                                global.db.data.users[m.sender].cupon += count * 1
                                global.db.data.users[m.sender].tiketcoin -= Btiketcoin * count
                                conn.reply(m.chat, `Succes membeli ${count} cupon dengan harga ${Btiketcoin * count} Tiketcoin`, m)
                            } else conn.reply(m.chat, `Tiketcoin anda tidak cukup untuk membeli ${count} cupon dengan harga ${Btiketcoin * count} Tiketcoin\n\nCara mendapatkan tiketcoin, anda harus memainkan semua fitur game..`.trim(), m)
                        
                        break 
                  case 'makananpet':
                            if (global.db.data.users[m.sender].money >= Bmakananpet * count) {
                                global.db.data.users[m.sender].makananpet += count * 1
                                global.db.data.users[m.sender].money -= Bmakananpet * count
                                conn.reply(m.chat, `Succes membeli ${count} Makanan Pet dengan harga ${Bmakananpet * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} makanan pet dengan harga ${Bmakananpet * count} money`.trim(), m)
                        
                        break 
                case 'makanannaga':
                            if (global.db.data.users[m.sender].money >= Bmakanannaga * count) {
                                global.db.data.users[m.sender].makanannaga += count * 1
                                global.db.data.users[m.sender].money -= Bmakanannaga * count
                                conn.reply(m.chat, `Succes membeli ${count} Makanan Naga dengan harga ${Bmakanannaga * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} makanan naga dengan harga ${Bmakanannaga * count} money`.trim(), m)
                        
                        break 
                 case 'makananphonix':
                            if (global.db.data.users[m.sender].money >= Bmakananphonix * count) {
                                global.db.data.users[m.sender].makananphonix += count * 1
                                global.db.data.users[m.sender].money -= Bmakananphonix * count
                                conn.reply(m.chat, `Succes membeli ${count} Makanan Phonix dengan harga ${Bmakananphonix * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} makanan phonix dengan harga ${Bmakananphonix * count} money`.trim(), m)
                        
                        break 
                case 'makanankyubi':
                            if (global.db.data.users[m.sender].money >= Bmakanankyubi * count) {
                                global.db.data.users[m.sender].makanankyubi += count * 1
                                global.db.data.users[m.sender].money -= Bmakanankyubi* count
                                conn.reply(m.chat, `Succes membeli ${count} Makanan Kyubi dengan harga ${Bmakanankyubi * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} makanan kyubi dengan harga ${Bmakanankyubi * count} money`.trim(), m)
                        
                        break 
                 case 'makanangriffin':
                            if (global.db.data.users[m.sender].money >= Bmakanangriffin * count) {
                                global.db.data.users[m.sender].makanangriffin += count * 1
                                global.db.data.users[m.sender].money -= Bmakanangriffin * count
                                conn.reply(m.chat, `Succes membeli ${count} Makanan Griffin dengan harga ${Bmakanangriffin * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} makanan griffin dengan harga ${Bmakanangriffin * count} money`.trim(), m)
                        
                        break 
                  case 'makanancentaur':
                            if (global.db.data.users[m.sender].money >= Bmakanancentaur * count) {
                                global.db.data.users[m.sender].makanancentaur += count * 1
                                global.db.data.users[m.sender].money -= Bmakanancentaur * count
                                conn.reply(m.chat, `Succes membeli ${count} Makanan Centaur dengan harga ${Bmakanancentaur * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} makanan centaur dengan harga ${Bmakanancentaur * count} money`.trim(), m)
                        
                        break 
                  case 'tiketm':
                            if (global.db.data.users[m.sender].money >= Bhealtmonster * count) {
                                global.db.data.users[m.sender].healtmonster += count * 1
                                global.db.data.users[m.sender].money -= Bhealtmonster * count
                                conn.reply(m.chat, `Succes membeli ${count} TiketM dengan harga ${Bhealtmonster * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} tiketm dengan harga ${Bhealtmonster * count} money`.trim(), m)
                        
                        break
                  case 'aqua':
                            if (global.db.data.users[m.sender].money >= Baqua * count) {
                                global.db.data.users[m.sender].aqua += count * 1
                                global.db.data.users[m.sender].money -= Baqua * count
                                conn.reply(m.chat, `Succes membeli ${count} Aqua dengan harga ${Baqua * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} aqua dengan harga ${Baqua * count} money`.trim(), m)
                        
                        break
                  case 'iron':
                            if (global.db.data.users[m.sender].money >= Biron * count) {
                                global.db.data.users[m.sender].iron += count * 1
                                global.db.data.users[m.sender].money -= Biron * count
                                conn.reply(m.chat, `Succes membeli ${count} Iron dengan harga ${Biron * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} iron dengan harga ${Biron * count} money`.trim(), m)
                        
                        break
                  case 'string':
                            if (global.db.data.users[m.sender].money >= Bstring * count) {
                                global.db.data.users[m.sender].string += count * 1
                                global.db.data.users[m.sender].money -= Bstring * count
                                conn.reply(m.chat, `Succes membeli ${count} String dengan harga ${Bstring * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} string dengan harga ${Bstring * count} money`.trim(), m)
                        
                        break
                  case 'sword':
                            if (global.db.data.users[m.sender].sword == 30) return conn.reply(m.chat, 'Sword sudah *Level Max*', m)
                            if (global.db.data.users[m.sender].money >= Bsword) {
                            let sword = global.db.data.users[m.sender].sword
                                global.db.data.users[m.sender].sword += 1
                                global.db.data.users[m.sender].money -= Bsword * 1
                                global.db.data.users[m.sender].sworddurability += 100 * sword
                                global.db.data.users[m.sender].sworddamage += 200 * sword
                                global.db.data.users[m.sender].barsword += 100 * sword
                                conn.reply(m.chat, swordsukses ,m)
                            } else conn.reply(m.chat, snomoney, m)
                        
                        break 
                  case 'batu':
                            if (global.db.data.users[m.sender].money >= Bbatu * count) {
                                global.db.data.users[m.sender].batu += count * 1
                                global.db.data.users[m.sender].money -= Bbatu * count
                                conn.reply(m.chat, `Succes membeli ${count} Batu dengan harga ${Bbatu * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} batu dengan harga ${Bbatu * count} money`.trim(), m)
                        
                        break 
                    case 'umpan':
                            if (global.db.data.users[m.sender].money >= Bumpan * count) {
                                global.db.data.users[m.sender].umpan += count * 1
                                global.db.data.users[m.sender].money -= Bumpan * count
                                conn.reply(m.chat, `Succes membeli ${count} Umpan dengan harga ${Bumpan * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} umpan dengan harga ${Bumpan * count} money`.trim(), m)
                        
                        break 
                        case 'aerozine':
                            if (global.db.data.users[m.sender].money >= Baero * count) {
                                global.db.data.users[m.sender].aerozine += count * 1
                                global.db.data.users[m.sender].money -= Baero * count
                                conn.reply(m.chat, `Succes membeli ${count} Aerozine dengan harga ${Baero * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Aerozine dengan harga ${Baero * count} money`.trim(), m)
                        
                        break 
                    case 'pancingan':
                         if (global.db.data.users[m.sender].pancingan == 1) return m.reply(`Kamu Sudah Memiliki Pancingan`)
                            if (global.db.data.users[m.sender].money >= Bpancingan) {
                                global.db.data.users[m.sender].pancingan += 1
                                global.db.data.users[m.sender].pancingandurability = 100
                                global.db.data.users[m.sender].money -= Bpancingan * 1
                                conn.reply(m.chat, `Succes membeli Pancingan dengan harga ${Bpancingan} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli pancingan dengan harga ${Bpancingan} money`.trim(), m)
                        
                        break
                    case 'sniper':
                         if (global.db.data.users[m.sender].sniper == 1) return m.reply(`Kamu Sudah Memiliki Sniper`)
                            if (global.db.data.users[m.sender].money >= Bsniper) {
                                global.db.data.users[m.sender].sniper += 1
                                global.db.data.users[m.sender].peluru = 30
                                global.db.data.users[m.sender].money -= Bsniper * 1
                                conn.reply(m.chat, `Succes membeli Sniper dengan harga ${Bsniper} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli Sniper dengan harga ${Bsniper} money`.trim(), m)
                        
                        break
                    case 'armor':
                            if (global.db.data.users[m.sender].armor == 20) return conn.reply(m.chat, 'Armormu sudah *Level Max*', m)
                            if (global.db.data.users[m.sender].money > Bharmor) {
                            let armor = global.db.data.users[m.sender].armor
                                global.db.data.users[m.sender].armor += 1
                                global.db.data.users[m.sender].healt += 100 * armor
                                global.db.data.users[m.sender].health += 100 * armor
                                global.db.data.users[m.sender].money -= Bharmor * 1
                                global.db.data.users[m.sender].armordurability += 100 * armor
                                global.db.data.users[m.sender].bararmor += 100 * armor
                                conn.reply(m.chat, armorsukses ,m)
                            } else conn.reply(m.chat, anomoney, m)
                        
                        break
                        case 'roket':
                            if (global.db.data.users[m.sender].roket == 1) return conn.reply(m.chat, 'Kamu Sudah Memiliki Ini', m)
                            if (global.db.data.users[m.sender].money > Broket) {
                            
                                global.db.data.users[m.sender].roket += 1;
                                global.db.data.users[m.sender].money -= Broket;
                                conn.reply(m.chat, `Sukses Membeli *🚀 Roket*, Dengan Harga Rp.${Hbroket} Money`,m)
                            } else conn.reply(m.chat, `Uangmu Tidak Cukup Untuk Membeli *🚀 Roket* Seharga Rp.${Hbroket} Money`, m)
                        
                        break
                    default:
                        return conn.reply(m.chat, Kchat, flok)
                }
                break
            case 'sell': 
                switch (_type) {
                    case 'potion':
                        if (global.db.data.users[m.sender].potion >= count * 1) {
                            global.db.data.users[m.sender].money += Spotion * count
                            global.db.data.users[m.sender].potion -= count * 1
                            conn.reply(m.chat, `Succes menjual ${count} Potion dengan harga ${Spotion * count} money`.trim(), m)
                        } else conn.reply(m.chat, `Potion kamu tidak cukup`.trim(), m)
                        break
                        case 'leather':
                        if (global.db.data.users[m.sender].leather >= count * 1) {
                            global.db.data.users[m.sender].money += Skulit * count
                            global.db.data.users[m.sender].leather -= count * 1
                            conn.reply(m.chat, `Succes menjual ${count} Leather dengan harga ${Skulit * count} money`.trim(), m)
                        } else conn.reply(m.chat, `Leather kamu tidak cukup`.trim(), m)
                        break
                    case 'common':
                        if (global.db.data.users[m.sender].common >= count * 1) {
                            global.db.data.users[m.sender].money += Scommon * count
                            global.db.data.users[m.sender].common -= count * 1
                            conn.reply(m.chat, `Succes menjual ${count} Common Crate dengan harga ${Scommon * count} money`.trim(), m)
                        } else conn.reply(m.chat, `Common Crate kamu tidak cukup`.trim(), m)
                        break
                    case 'coal':
                        if (global.db.data.users[m.sender].coal >= count * 1) {
                            global.db.data.users[m.sender].money += Scoal * count
                            global.db.data.users[m.sender].coal -= count * 1
                            conn.reply(m.chat, `Succes menjual ${count} Coal dengan harga ${Scoal * count} money`.trim(), m)
                        } else conn.reply(m.chat, `Coal kamu tidak cukup`.trim(), m)
                        break
                    case 'peluru':
                        if (global.db.data.users[m.sender].peluru >= count * 1) {
                            global.db.data.users[m.sender].money += Speluru * count
                            global.db.data.users[m.sender].peluru -= count * 1
                            conn.reply(m.chat, `Succes menjual ${count} Peluru dengan harga ${Speluru * count} money`.trim(), m)
                        } else conn.reply(m.chat, `Peluru kamu tidak cukup`.trim(), m)
                        break
                    case 'uncommon':
                        if (global.db.data.users[m.sender].uncommon >= count * 1) {
                            global.db.data.users[m.sender].money += Suncommon * count
                            global.db.data.users[m.sender].uncommon -= count * 1
                            conn.reply(m.chat, `Succes menjual ${count} Uncommon Crate dengan harga ${Suncommon * count} money`.trim(), m)
                        } else conn.reply(m.chat, `Uncommon Crate kamu tidak cukup`.trim(), m)
                        break
                    case 'mythic':
                        if (global.db.data.users[m.sender].mythic >= count * 1) {
                            global.db.data.users[m.sender].money += Smythic * count
                            global.db.data.users[m.sender].mythic -= count * 1
                            conn.reply(m.chat, `Succes menjual ${count} Mythic Crate dengan harga ${Smythic * count} money`.trim(), m)
                        } else conn.reply(m.chat, `Mythic Crate kamu tidak cukup`.trim(), m)
                        break
                    case 'legendary':
                        if (global.db.data.users[m.sender].legendary >= count * 1) {
                            global.db.data.users[m.sender].money += Slegendary * count
                            global.db.data.users[m.sender].legendary -= count * 1
                            conn.reply(m.chat, `Succes menjual ${count} Legendary Crate dengan harga ${Slegendary * count} money`.trim(), m)
                        } else conn.reply(m.chat, `Legendary Crate kamu tidak cukup`.trim(), m)
                        break
                    case 'sampah':
                        if (global.db.data.users[m.sender].sampah >= count * 1) {
                            global.db.data.users[m.sender].sampah -= count * 1
                            global.db.data.users[m.sender].money += Ssampah * count
                            conn.reply(m.chat, `Succes menjual ${count} sampah, dan anda mendapatkan ${Ssampah * count} money`, m)
                        } else conn.reply(m.chat, `Sampah anda tidak cukup`, m)
                        break
                    case 'kaleng':
                        if (global.db.data.users[m.sender].kaleng >= count * 1) {
                            global.db.data.users[m.sender].kaleng -= count * 1
                            global.db.data.users[m.sender].money += Skaleng * count
                            conn.reply(m.chat, `Succes menjual ${count} kaleng, dan anda mendapatkan ${Skaleng * count} money`, m)
                        } else conn.reply(m.chat, `Kaleng anda tidak cukup`, m)
                        break
                    case 'kardus':
                        if (global.db.data.users[m.sender].kardus >= count * 1) {
                            global.db.data.users[m.sender].kardus -= count * 1
                            global.db.data.users[m.sender].money += Skardus * count
                            conn.reply(m.chat, `Succes menjual ${count} kardus, dan anda mendapatkan ${Skardus * count} money`, m)
                        } else conn.reply(m.chat, `Kardus anda tidak cukup`, m)
                        break
                    case 'plastik':
                        if (global.db.data.users[m.sender].pelastik >= count * 1) {
                            global.db.data.users[m.sender].pelastik -= count * 1
                            global.db.data.users[m.sender].money += Spelastik * count
                            conn.reply(m.chat, `Succes menjual ${count} plastik, dan anda mendapatkan ${Spelastik * count} money`, m)
                        } else conn.reply(m.chat, `plastik anda tidak cukup`, m)
                        break
                    case 'botol':
                        if (global.db.data.users[m.sender].botol >= count * 1) {
                            global.db.data.users[m.sender].botol -= count * 1
                            global.db.data.users[m.sender].money += Sbotol * count
                            conn.reply(m.chat, `Succes menjual ${count} botol, dan anda mendapatkan ${Sbotol * count} money`, m)
                        } else conn.reply(m.chat, `Botol anda tidak cukup`, m)
                        break
                    case 'kayu':
                        if (global.db.data.users[m.sender].kayu >= count * 1) {
                            global.db.data.users[m.sender].kayu -= count * 1
                            global.db.data.users[m.sender].money += Skayu * count
                            conn.reply(m.chat, `Succes menjual ${count} kayu, dan anda mendapatkan ${Skayu * count} money`, m)
                        } else conn.reply(m.chat, `Kayu anda tidak cukup`, m)
                        break
                    case 'pisang':
                        if (global.db.data.users[m.sender].pisang >= count * 1) {
                            global.db.data.users[m.sender].pisang -= count * 1
                            global.db.data.users[m.sender].money += Spisang * count
                            conn.reply(m.chat, `Succes menjual ${count} pisang, dan anda mendapatkan ${Spisang * count} money`, m)
                        } else conn.reply(m.chat, `Pisang anda tidak cukup`, m)
                        break
                    case 'anggur':
                        if (global.db.data.users[m.sender].anggur >= count * 1) {
                            global.db.data.users[m.sender].anggur -= count * 1
                            global.db.data.users[m.sender].money += Sanggur * count
                            conn.reply(m.chat, `Succes menjual ${count} anggur, dan anda mendapatkan ${Sanggur * count} money`, m)
                        } else conn.reply(m.chat, `Anggur anda tidak cukup`, m)
                        break
                    case 'mangga':
                        if (global.db.data.users[m.sender].mangga >= count * 1) {
                            global.db.data.users[m.sender].mangga -= count * 1
                            global.db.data.users[m.sender].money += Smangga * count
                            conn.reply(m.chat, `Succes menjual ${count} mangga, dan anda mendapatkan ${Smangga * count} money`, m)
                        } else conn.reply(m.chat, `Mangga anda tidak cukup`, m)
                        break
                    case 'jeruk':
                        if (global.db.data.users[m.sender].jeruk >= count * 1) {
                            global.db.data.users[m.sender].jeruk -= count * 1
                            global.db.data.users[m.sender].money += Sjeruk * count
                            conn.reply(m.chat, `Succes menjual ${count} jeruk, dan anda mendapatkan ${Sjeruk * count} money`, m)
                        } else conn.reply(m.chat, `Jeruk anda tidak cukup`, m)
                        break
                    case 'apel':
                        if (global.db.data.users[m.sender].apel >= count * 1) {
                            global.db.data.users[m.sender].apel -= count * 1
                            global.db.data.users[m.sender].money += Sapel * count
                            conn.reply(m.chat, `Succes menjual ${count} apel, dan anda mendapatkan ${Sapel * count} money`, m)
                        } else conn.reply(m.chat, `Apel anda tidak cukup`, m)
                        break
                   case 'aerozine':
                        if (global.db.data.users[m.sender].aerozine >= count * 1) {
                            global.db.data.users[m.sender].aerozine -= count * 1
                            global.db.data.users[m.sender].money += Saero * count
                            conn.reply(m.chat, `Succes menjual ${count} Aerozine, dan anda mendapatkan ${Saero * count} money`, m)
                        } else conn.reply(m.chat, `Aerozine anda tidak cukup`, m)
                        break
                   case 'berlian':
                        if (global.db.data.users[m.sender].berlian >= count * 1) {
                            global.db.data.users[m.sender].berlian -= count * 1
                            global.db.data.users[m.sender].money += Sberlian * count
                            conn.reply(m.chat, `Succes menjual ${count} berlian, dan anda mendapatkan ${Sberlian * count} money`, m)
                        } else conn.reply(m.chat, `Berlian anda tidak cukup`, m)
                        break
                   case 'emas':
                        if (global.db.data.users[m.sender].emas >= count * 1) {
                            global.db.data.users[m.sender].emas -= count * 1
                            global.db.data.users[m.sender].money += Semasbiasa * count
                            conn.reply(m.chat, `Succes menjual ${count} emas , dan anda mendapatkan ${Semasbiasa * count} money`, m)
                        } else conn.reply(m.chat, `Emas anda tidak cukup`, m)
                        break  
                    case 'pet':
                        if (global.db.data.users[m.sender].pet >= count * 1) {
                            global.db.data.users[m.sender].pet -= count * 1
                            global.db.data.users[m.sender].money += Spet * count
                            conn.reply(m.chat, `Succes menjual ${count} pet random, dan anda mendapatkan ${Spet * count} money`, m)
                        } else conn.reply(m.chat, `Pet Random anda tidak cukup`, m)
                        break 
                    case 'makananpet':
                        if (global.db.data.users[m.sender].makananpet >= count * 1) {
                            global.db.data.users[m.sender].makananpet -= count * 1
                            global.db.data.users[m.sender].money += Smakananpet * count
                            conn.reply(m.chat, `Succes menjual ${count} makanan pet, dan anda mendapatkan ${Smakananpet * count} money`, m)
                        } else conn.reply(m.chat, `Makanan pet anda tidak cukup`, m)
                        break 
                    case 'makananphonix':
                        if (global.db.data.users[m.sender].makananphonix >= count * 1) {
                            global.db.data.users[m.sender].makananphonix -= count * 1
                            global.db.data.users[m.sender].money += Smakananphonix * count
                            conn.reply(m.chat, `Succes menjual ${count} makanan phonix, dan anda mendapatkan ${Smakananphonix * count} money`, m)
                        } else conn.reply(m.chat, `Makanan phonix anda tidak cukup`, m)
                        break
                    case 'makanannaga':
                        if (global.db.data.users[m.sender].makanannaga >= count * 1) {
                            global.db.data.users[m.sender].makanannaga -= count * 1
                            global.db.data.users[m.sender].money += Smakanannaga * count
                            conn.reply(m.chat, `Succes menjual ${count} makanan naga, dan anda mendapatkan ${Smakanannaga * count} money`, m)
                        } else conn.reply(m.chat, `Makanan naga anda tidak cukup`, m)
                        break
                    case 'makanankyubi':
                        if (global.db.data.users[m.sender].makanankyuni >= count * 1) {
                            global.db.data.users[m.sender].makanankyubi -= count * 1
                            global.db.data.users[m.sender].money += Smakanankyubi * count
                            conn.reply(m.chat, `Succes menjual ${count} makanan kyubi, dan anda mendapatkan ${Smakanankyubi* count} money`, m)
                        } else conn.reply(m.chat, `Makanan kyubi anda tidak cukup`, m)
                        break
                    case 'makanangriffin':
                        if (global.db.data.users[m.sender].makanangriffin >= count * 1) {
                            global.db.data.users[m.sender].makanangriffin -= count * 1
                            global.db.data.users[m.sender].money += Smakanangriffin * count
                            conn.reply(m.chat, `Succes menjual ${count} makanan griffin, dan anda mendapatkan ${Smakanangriffin * count} money`, m)
                        } else conn.reply(m.chat, `Makanan griffin anda tidak cukup`, m)
                        break 
                    case 'makanancentaur':
                        if (global.db.data.users[m.sender].makanancentaur >= count * 1) {
                            global.db.data.users[m.sender].makanancentaur -= count * 1
                            global.db.data.users[m.sender].money += Smakanancentaur * count
                            conn.reply(m.chat, `Succes menjual ${count} makanan centaur, dan anda mendapatkan ${Smakanancentaur * count} money`, m)
                        } else conn.reply(m.chat, `Makanan centaur anda tidak cukup`, m)
                        break
                    case 'aqua':
                        if (global.db.data.users[m.sender].aqua >= count * 1) {
                            global.db.data.users[m.sender].aqua -= count * 1
                            global.db.data.users[m.sender].money += Saqua * count
                            conn.reply(m.chat, `Succes menjual ${count} aqua, dan anda mendapatkan ${Saqua * count} money`, m)
                        } else conn.reply(m.chat, `Aqua anda tidak cukup`, m)
                        break
                    case 'iron':
                        if (global.db.data.users[m.sender].iron >= count * 1) {
                            global.db.data.users[m.sender].iron -= count * 1
                            global.db.data.users[m.sender].money += Siron * count
                            conn.reply(m.chat, `Succes menjual ${count} pancingan, dan anda mendapatkan ${Siron * count} money`, m)
                        } else conn.reply(m.chat, `Iron anda tidak cukup`, m)
                        break
                    case 'string':
                        if (global.db.data.users[m.sender].string >= count * 1) {
                            global.db.data.users[m.sender].string -= count * 1
                            global.db.data.users[m.sender].money += Sstring * count
                            conn.reply(m.chat, `Succes menjual ${count} string, dan anda mendapatkan ${Sstring * count} money`, m)
                        } else conn.reply(m.chat, `String anda tidak cukup`, m)
                        break
                    case 'batu':
                        if (global.db.data.users[m.sender].batu >= count * 1) {
                            global.db.data.users[m.sender].batu -= count * 1
                            global.db.data.users[m.sender].money += Sbatu * count
                            conn.reply(m.chat, `Succes menjual ${count} batu, dan anda mendapatkan ${Sbatu * count} money`, m)
                        } else conn.reply(m.chat, `Batu anda tidak cukup`, m)
                        break
                    case 'limit':
                        if (global.db.data.users[m.sender].limit >= count * 1) {
                            global.db.data.users[m.sender].limit -= count * 1
                            global.db.data.users[m.sender].money += Slimit * count
                            conn.reply(m.chat, `Succes menjual ${count} limit, dan anda mendapatkan ${Slimit * count} money`, m)
                        } else conn.reply(m.chat, `Limit anda tidak cukup`, m)
                        break
                    case 'diamond':
                        if (global.db.data.users[m.sender].diamond >= count * 1) {
                            global.db.data.users[m.sender].diamond -= count * 1
                            global.db.data.users[m.sender].money += Sdiamond * count
                            conn.reply(m.chat, `Succes menjual ${count} Diamond, dan anda mendapatkan ${Sdiamond * count} money`, m)
                        } else conn.reply(m.chat, `Diamond anda tidak cukup`, m)
                        break
                    default:
                        return conn.reply(m.chat, Kchat, flok)
                }
                break
            default:
                return conn.reply(m.chat, Kchat, flok)
            }
        } else if (/beli|buy/i.test(command)) {
            const count = args[1] && args[1].length > 0 ? Math.min(999999999999999, Math.max(parseInt(args[1]), 1)) : !args[1] || args.length < 3 ? 1 : Math.min(1, count)
            switch (type) {
                case 'potion':
                        if (global.db.data.users[m.sender].money >= potion * count) {
                            global.db.data.users[m.sender].money -= potion * count
                            global.db.data.users[m.sender].potion += count * 1
                            conn.reply(m.chat, `Succes membeli ${count} Potion dengan harga ${potion * count} money`, m)
                        } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Potion dengan harga ${potion * count} money`,m)
                    
                    break
                    case 'leather':
                            if (global.db.data.users[m.sender].money >= Bkulit * count) {
                                global.db.data.users[m.sender].money -= Bkulit * count
                                global.db.data.users[m.sender].leather += count * 1
                                conn.reply(m.chat, `Succes membeli ${count} Leather dengan harga ${potion * count} money*`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Leather dengan harga ${Bkulit * count} money`,)
                        break
                case 'diamond':
                        if (global.db.data.users[m.sender].money >= Bdiamond * count) {
                            global.db.data.users[m.sender].diamond += count * 1
                            global.db.data.users[m.sender].money -= Bdiamond * count
                            conn.reply(m.chat, `Succes membeli ${count} Diamond dengan harga ${Bdiamond * count} money`, m)
                        } else conn.reply(m.chat, `Money anda tidak cukup`, m)
                    
                    break
                case 'common':
                        if (global.db.data.users[m.sender].money >= Bcommon * count) {
                            global.db.data.users[m.sender].common += count * 1
                            global.db.data.users[m.sender].money -= Bcommon * count
                            conn.reply(m.chat, `Succes membeli ${count} Common crate dengan harga ${Bcommon * count} money`, m)
                        } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Common crate dengan harga ${Bcommon * count} money\n\nBuka crate dengan ketik: *${usedPrefix}open common*`, m)
                    
                    break
                case 'uncommon':
                        if (global.db.data.users[m.sender].money >= Buncommon * count) {
                            global.db.data.users[m.sender].uncommon += count * 1
                            global.db.data.users[m.sender].money -= Buncommon * count
                            conn.reply(m.chat, `Succes membeli ${count} Uncommon crate dengan harga ${Buncommon * count} money`, m)
                        } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Uncommon crate dengan harga ${Buncommon * count} money\n\nBuka crate dengan ketik: *${usedPrefix}open uncommon*`, m)
                   
                    break
                case 'mythic':
                        if (global.db.data.users[m.sender].money >= Bmythic * count) {
                            global.db.data.users[m.sender].mythic += count * 1
                            global.db.data.users[m.sender].money -= Bmythic * count
                            conn.reply(m.chat, `Succes membeli ${count} Mythic crate dengan harga ${Bmythic * count} money`, m)
                        } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Mythic crate dengan harga ${Bmythic* count} money\n\nBuka crate dengan ketik: *${usedPrefix}open mythic*`, m)
                    
                    break
                case 'legendary':
                        if (global.db.data.users[m.sender].money >= Blegendary * count) {
                            global.db.data.users[m.sender].legendary += count * 1
                            global.db.data.users[m.sender].money -= Blegendary * count
                            conn.reply(m.chat, `Succes membeli ${count} Legendary crate dengan harga ${Blegendary * count} money`, m)
                        } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Legendary crate dengan harga ${Blegendary * count} money\n\nBuka crate dengan ketik: *${usedPrefix}open legendary*`, m)
                    
                    break
                case 'sampah':
                        if (global.db.data.users[m.sender].money >= Bsampah * count) {
                            global.db.data.users[m.sender].sampah += count * 1
                            global.db.data.users[m.sender].money -= Bsampah * count
                            conn.reply(m.chat, `Succes membeli ${count} Sampah dengan harga ${Bsampah * count} money`, m)
                        } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Sampah dengan harga ${Bsampah * count} money`.trim(), m)
                    
                    break
                    case 'kaleng':
                            if (global.db.data.users[m.sender].money >= Bkaleng * count) {
                                global.db.data.users[m.sender].kaleng += count * 1
                                global.db.data.users[m.sender].money -= Bkaleng * count
                                conn.reply(m.chat, `Succes membeli ${count} Kaleng dengan harga ${Bkaleng * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Kaleng dengan harga ${Bkaleng * count} money`.trim(), m)
                        
                        break
                    case 'kardus':
                            if (global.db.data.users[m.sender].money >= Bkardus * count) {
                                global.db.data.users[m.sender].kardus += count * 1
                                global.db.data.users[m.sender].money -= Bkardus * count
                                conn.reply(m.chat, `Succes membeli ${count} Kardus dengan harga ${Bkardus * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Kardus dengan harga ${Bkardus * count} money`.trim(), m)
                        
                        break
                    case 'botol':
                            if (global.db.data.users[m.sender].money >= Bbotol * count) {
                                global.db.data.users[m.sender].botol += count * 1
                                global.db.data.users[m.sender].money -= Bbotol * count
                                conn.reply(m.chat, `Succes membeli ${count} Botol dengan harga ${Bbotol * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} botol dengan harga ${Bbotol * count} money`.trim(), m)
                        
                        break
                    case 'kayu':
                            if (global.db.data.users[m.sender].money >= Bkayu * count) {
                                global.db.data.users[m.sender].kayu += count * 1
                                global.db.data.users[m.sender].money -= Bkayu * count
                                conn.reply(m.chat, `Succes membeli ${count} Kayu dengan harga ${Bkayu * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} kayu dengan harga ${Bkayu * count} money`.trim(), m)
                        
                        break
                    case 'pisang':
                            if (global.db.data.users[m.sender].money >= Bpisang * count) {
                                global.db.data.users[m.sender].pisang += count * 1
                                global.db.data.users[m.sender].money -= Bpisang * count
                                conn.reply(m.chat, `Succes membeli ${count} Pisang dengan harga ${Bpisang * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} pisang dengan harga ${Bpisang * count} money`.trim(), m)
                        
                        break
                    case 'anggur':
                            if (global.db.data.users[m.sender].money >= Banggur * count) {
                                global.db.data.users[m.sender].anggur += count * 1
                                global.db.data.users[m.sender].money -= Banggur * count
                                conn.reply(m.chat, `Succes membeli ${count} Anggur dengan harga ${Banggur * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} anggur dengan harga ${Banggur * count} money`.trim(), m)
                        
                        break
                    case 'mangga':
                            if (global.db.data.users[m.sender].money >= Bmangga * count) {
                                global.db.data.users[m.sender].mangga += count * 1
                                global.db.data.users[m.sender].money -= Bmangga * count
                                conn.reply(m.chat, `Succes membeli ${count} Mangga dengan harga ${Bmangga * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} mangga dengan harga ${Bmangga * count} money`.trim(), m)
                        
                        break
                    case 'jeruk':
                            if (global.db.data.users[m.sender].money >= Bjeruk * count) {
                                global.db.data.users[m.sender].jeruk += count * 1
                                global.db.data.users[m.sender].money -= Bjeruk * count
                                conn.reply(m.chat, `Succes membeli ${count} Jeruk dengan harga ${Bjeruk * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} jeruk dengan harga ${Bjeruk * count} money`.trim(), m)
                        
                        break
                    case 'apel':
                            if (global.db.data.users[m.sender].money >= Bapel * count) {
                                global.db.data.users[m.sender].apel += count * 1
                                global.db.data.users[m.sender].money -= Bapel * count
                                conn.reply(m.chat, `Succes membeli ${count} Apel dengan harga ${Bapel * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} apel dengan harga ${Bapel * count} money`.trim(), m)
                        
                        break
                    case 'bibitpisang':
                            if (global.db.data.users[m.sender].money >= Bbibitpisang * count) {
                                global.db.data.users[m.sender].bibitpisang += count * 1
                                global.db.data.users[m.sender].money -= Bbibitpisang * count
                                conn.reply(m.chat, `Succes membeli ${count} Bibit Pisang dengan harga ${Bbibitpisang * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} bibit pisang dengan harga ${Bbibitpisang * count} money`.trim(), m)
                        
                        break
                    case 'bibitanggur':
                            if (global.db.data.users[m.sender].money >= Bbibitanggur * count) {
                                global.db.data.users[m.sender].bibitanggur += count * 1
                                global.db.data.users[m.sender].money -= Bbibitanggur * count
                                conn.reply(m.chat, `Succes membeli ${count} Bibit Anggur dengan harga ${Bbibitanggur * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} bibit anggur dengan harga ${Bbibitanggur * count} money`.trim(), m)
                        
                        break
                    case 'bibitmangga':
                            if (global.db.data.users[m.sender].money >= Bbibitmangga * count) {
                                global.db.data.users[m.sender].bibitmangga += count * 1
                                global.db.data.users[m.sender].money -= Bbibitmangga * count
                                conn.reply(m.chat, `Succes membeli ${count} Bibit Mangga dengan harga ${Bbibitmangga * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} bibit mangga dengan harga ${Bbibitmangga * count} money`.trim(), m)
                        
                        break
                    case 'bibitjeruk':
                            if (global.db.data.users[m.sender].money >= Bbibitjeruk * count) {
                                global.db.data.users[m.sender].bibitjeruk += count * 1
                                global.db.data.users[m.sender].money -= Bbibitjeruk * count
                                conn.reply(m.chat, `Succes membeli ${count} Bibit Jeruk dengan harga ${Bbibitjeruk * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} bibit jeruk dengan harga ${Bbibitjeruk * count} money`.trim(), m)
                        
                        break
                    case 'bibitapel':
                            if (global.db.data.users[m.sender].money >= Bbibitapel * count) {
                                global.db.data.users[m.sender].bibitapel += count * 1
                                global.db.data.users[m.sender].money -= Bbibitapel * count
                                conn.reply(m.chat, `Succes membeli ${count} Bibit Apel dengan harga ${Bbibitapel * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} bibit apel dengan harga ${Bbibitapel * count} money`.trim(), m)
                        
                        break 
                    case 'gardenboxs':
                            if (global.db.data.users[m.sender].money >= Bgardenboxs * count) {
                                global.db.data.users[m.sender].gardenboxs += count * 1
                                global.db.data.users[m.sender].money -= Bgardenboxs * count
                                conn.reply(m.chat, `Succes membeli ${count} Gardenboxs dengan harga ${Bgardenboxs * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} gardenboxs dengan harga ${Bgardenboxs * count} money`.trim(), m)
                        
                        break
                    case 'berlian':
                            if (global.db.data.users[m.sender].money >= Bberlian * count) {
                                global.db.data.users[m.sender].berlian += count * 1
                                global.db.data.users[m.sender].money -= Bberlian * count
                                conn.reply(m.chat, `Succes membeli ${count} Apel dengan harga ${Bberlian * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} berlian dengan harga ${Bberlian * count} money`.trim(), m)
                        
                        break
                    case 'emas':
                            if (global.db.data.users[m.sender].money >= Bemasbiasa * count) {
                                global.db.data.users[m.sender].emas += count * 1
                                global.db.data.users[m.sender].money -= Bemasbiasa * count
                                conn.reply(m.chat, `Succes membeli ${count} Emas dengan harga ${Bemasbiasa * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} emas dengan harga ${Bemasbiasa * count} money`.trim(), m)
                        
                        break  
                     case 'pet':
                            if (global.db.data.users[m.sender].money >= Bpet * count) {
                                global.db.data.users[m.sender].pet += count * 1
                                global.db.data.users[m.sender].money -= Bpet * count
                                conn.reply(m.chat, `Succes membeli ${count} Pet Random dengan harga ${Bpet * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} pet random dengan harga ${Bpet * count} money`.trim(), m)
                        
                        break
                  case 'limit':
                            if (global.db.data.users[m.sender].money >= Blimit * count) {
                                global.db.data.users[m.sender].limit += count * 1
                                global.db.data.users[m.sender].money -= Blimit * count
                                conn.reply(m.chat, `Succes membeli ${count} Limit dengan harga ${Blimit * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} limit dengan harga ${Blimit * count} money`.trim(), m)
                        
                        break 
                   /*case 'exp':
                            if (global.db.data.users[m.sender].money >= Bexp * count) {
                                global.db.data.users[m.sender].exp += count * 1
                                global.db.data.users[m.sender].money -= Bexp * count
                                conn.reply(m.chat, `Succes membeli ${count} Exp dengan harga ${Bexp * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} exp dengan harga ${Bexp * count} money`.trim(), m)
                        
                        break
                     case 'eleksirb':
                            if (global.db.data.users[m.sender].money >= Beleksirb * count) {
                                global.db.data.users[m.sender].eleksirb += count * 1
                                global.db.data.users[m.sender].money -= Beleksirb * count
                                conn.reply(m.chat, `Succes membeli ${count} Eleksir Biru dengan harga ${Beleksirb * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} Eleksir Biru dengan harga ${Beleksirb * count} money`.trim(), m)
                        
                        break
                        case 'koinexpg':
                            if (global.db.data.users[m.sender].money >= Bkoinexpg * count) {
                                global.db.data.users[m.sender].koinexpg += count * 1
                                global.db.data.users[m.sender].money -= Bkoinexpg * count
                                conn.reply(m.chat, `Succes membeli ${count} Koinexpg dengan harga ${Bkoinexpg * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} koinexpg dengan harga ${Bkoinexpg * count} money`.trim(), m)
                        
                        break*/
                  case 'cupon':
                            if (global.db.data.users[m.sender].tiketcoin >= Btiketcoin * count) {
                                global.db.data.users[m.sender].cupon += count * 1
                                global.db.data.users[m.sender].tiketcoin -= Btiketcoin * count
                                conn.reply(m.chat, `Succes membeli ${count} cupon dengan harga ${Btiketcoin * count} Tiketcoin`, m)
                            } else conn.reply(m.chat, `Tiketcoin anda tidak cukup untuk membeli ${count} cupon dengan harga ${Btiketcoin * count} Tiketcoin\n\nCara mendapatkan tiketcoin, anda harus memainkan semua fitur game..`.trim(), m)
                        
                        break 
                 case 'makananpet':
                            if (global.db.data.users[m.sender].money >= Bmakananpet * count) {
                                global.db.data.users[m.sender].makananpet += count * 1
                                global.db.data.users[m.sender].money -= Bmakananpet * count
                                conn.reply(m.chat, `Succes membeli ${count} Makanan Pet dengan harga ${Bmakananpet * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} makanan pet dengan harga ${Bmakananpet * count} money`.trim(), m)
                        
                        break
                case 'makanannaga':
                            if (global.db.data.users[m.sender].money >= Bmakanannaga * count) {
                                global.db.data.users[m.sender].makanannaga += count * 1
                                global.db.data.users[m.sender].money -= Bmakanannaga * count
                                conn.reply(m.chat, `Succes membeli ${count} Makanan Naga dengan harga ${Bmakanannaga * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} makanan pet dengan harga ${Bmakanannaga * count} money`.trim(), m)
                        
                        break 
                 case 'makananphonix':
                            if (global.db.data.users[m.sender].money >= Bmakananphonix * count) {
                                global.db.data.users[m.sender].makananphonix += count * 1
                                global.db.data.users[m.sender].money -= Bmakananphonix * count
                                conn.reply(m.chat, `Succes membeli ${count} Makanan Phonix dengan harga ${Bmakananphonix * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} makanan pet dengan harga ${Bmakananphonix * count} money`.trim(), m)
                        
                        break 
                case 'makanankyubi':
                            if (global.db.data.users[m.sender].money >= Bmakanankyubi * count) {
                                global.db.data.users[m.sender].makanankyubi += count * 1
                                global.db.data.users[m.sender].money -= Bmakanankyubi* count
                                conn.reply(m.chat, `Succes membeli ${count} Makanan Kyubi dengan harga ${Bmakanankyubi * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} makanan kyubi dengan harga ${Bmakanankyubi * count} money`.trim(), m)
                        
                        break 
                 case 'makanangriffin':
                            if (global.db.data.users[m.sender].money >= Bmakanangriffin * count) {
                                global.db.data.users[m.sender].makanangriffin += count * 1
                                global.db.data.users[m.sender].money -= Bmakanangriffin * count
                                conn.reply(m.chat, `Succes membeli ${count} Makanan Griffin dengan harga ${Bmakanangriffin * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} makanan griffin dengan harga ${Bmakanangriffin * count} money`.trim(), m)
                        
                        break 
                  case 'makanancentaur':
                            if (global.db.data.users[m.sender].money >= Bmakanancentaur * count) {
                                global.db.data.users[m.sender].makanancentaur += count * 1
                                global.db.data.users[m.sender].money -= Bmakanancentaur * count
                                conn.reply(m.chat, `Succes membeli ${count} Makanan Centaur dengan harga ${Bmakanancentaur * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} makanan centaur dengan harga ${Bmakanancentaur * count} money`.trim(), m)
                        
                        break 
                case 'tiketm':
                            if (global.db.data.users[m.sender].money >= Bhealtmonster * count) {
                                global.db.data.users[m.sender].healtmonster += count * 1
                                global.db.data.users[m.sender].money -= Bhealtmonster * count
                                conn.reply(m.chat, `Succes membeli ${count} TiketM dengan harga ${Bhealtmonster * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} tiketm dengan harga ${Bhealtmonster * count} money`.trim(), m)
                        
                        break
                  case 'aqua':
                            if (global.db.data.users[m.sender].money >= Baqua * count) {
                                global.db.data.users[m.sender].aqua += count * 1
                                global.db.data.users[m.sender].money -= Baqua * count
                                conn.reply(m.chat, `Succes membeli ${count} Aqua dengan harga ${Baqua * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} aqua dengan harga ${Baqua * count} money`.trim(), m)
                        
                        break
                  case 'iron':
                            if (global.db.data.users[m.sender].money >= Biron * count) {
                                global.db.data.users[m.sender].iron += count * 1
                                global.db.data.users[m.sender].money -= Biron * count
                                conn.reply(m.chat, `Succes membeli ${count} Iron dengan harga ${Biron * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} iron dengan harga ${Biron * count} money`.trim(), m)
                        
                        break
                  case 'string':
                            if (global.db.data.users[m.sender].money >= Bstring * count) {
                                global.db.data.users[m.sender].string += count * 1
                                global.db.data.users[m.sender].money -= Bstring * count
                                conn.reply(m.chat, `Succes membeli ${count} String dengan harga ${Bstring * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} string dengan harga ${Bstring * count} money`.trim(), m)
                        
                        break
                  case 'sword':
                            if (global.db.data.users[m.sender].sword == 30) return conn.reply(m.chat, 'Sword sudah *Level Max*', m)
                            if (global.db.data.users[m.sender].money >= Bsword) {
                            let sword = global.db.data.users[m.sender].sword
                                global.db.data.users[m.sender].sword += 1
                                global.db.data.users[m.sender].money -= Bsword * 1
                                global.db.data.users[m.sender].sworddurability += 100 * sword
                                global.db.data.users[m.sender].sworddamage += 200 * sword
                                global.db.data.users[m.sender].barsword += 100 * sword
                                conn.reply(m.chat, swordsukses ,m)
                            } else conn.reply(m.chat, snomoney, m)
                        
                        break 
                  case 'batu':
                            if (global.db.data.users[m.sender].money >= Bbatu * count) {
                                global.db.data.users[m.sender].batu += count * 1
                                global.db.data.users[m.sender].money -= Bbatu * count
                                conn.reply(m.chat, `Succes membeli ${count} Batu dengan harga ${Bbatu * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} batu dengan harga ${Bbatu * count} money`.trim(), m)
                        
                        break 
                 case 'umpan':
                            if (global.db.data.users[m.sender].money >= Bumpan * count) {
                                global.db.data.users[m.sender].umpan += count * 1
                                global.db.data.users[m.sender].money -= Bumpan * count
                                conn.reply(m.chat, `Succes membeli ${count} Umpan dengan harga ${Bumpan * count} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli ${count} umpan dengan harga ${Bumpan * count} money`.trim(), m)
                        
                        break
                    case 'pancingan':
                        if (global.db.data.users[m.sender].pancingan == 1) return m.reply(`Kamu Sudah Memiliki Pancingan`)
                            if (global.db.data.users[m.sender].money >= Bpancingan * 1) {
                                global.db.data.users[m.sender].pancingan += 1
                                global.db.data.users[m.sender].pancingandurability = 100
                                global.db.data.users[m.sender].money -= Bpancingan * 1
                                conn.reply(m.chat, `Succes membeli Pancingan dengan harga ${Bpancingan} money`, m)
                            } else conn.reply(m.chat, `Uang anda tidak cukup untuk membeli pancingan dengan harga ${Bpancingan} money`.trim(), m)
                        
                        break
                case 'armor':
                            if (global.db.data.users[m.sender].armor == 20) return conn.reply(m.chat, 'Armormu sudah *Level Max*', m)
                            if (global.db.data.users[m.sender].money > Bharmor) {
                            let armor = global.db.data.users[m.sender].armor
                                global.db.data.users[m.sender].armor += 1
                                global.db.data.users[m.sender].healt += 100 * armor
                                global.db.data.users[m.sender].health += 100 * armor
                                global.db.data.users[m.sender].money -= Bharmor * 1
                                global.db.data.users[m.sender].armordurability += 100 * armor
                                global.db.data.users[m.sender].bararmor += 100 * armor
                                conn.reply(m.chat, armorsukses ,m)
                            } else conn.reply(m.chat, anomoney, m)
                        
                        break
                default:
                    return conn.reply(m.chat, Kchat, flok)
            }
        } else if (/sell|jual|/i.test(command)) {
            const count = args[1] && args[1].length > 0 ? Math.min(999999999999999, Math.max(parseInt(args[1]), 1)) : !args[1] || args.length < 3 ? 1 : Math.min(1, count)
            switch (type) {
                case 'potion':
                    if (global.db.data.users[m.sender].potion >= count * 1) {
                        global.db.data.users[m.sender].money += Spotion * count
                        global.db.data.users[m.sender].potion -= count * 1
                        conn.reply(m.chat, `Succes menjual ${count} Potion dengan harga ${Spotion * count} money`.trim(), m)
                    } else conn.reply(m.chat, `Potion kamu tidak cukup`.trim(), m)
                    break
                    case 'leather':
                        if (global.db.data.users[m.sender].leather >= count * 1) {
                            global.db.data.users[m.sender].money += Skulit * count
                            global.db.data.users[m.sender].leather -= count * 1
                            conn.reply(m.chat, `Succes menjual ${count} Leather dengan harga ${Skulit * count} money`.trim(), m)
                        } else conn.reply(m.chat, `Leather kamu tidak cukup`.trim(), m)
                        break
                case 'common':
                    if (global.db.data.users[m.sender].common >= count * 1) {
                        global.db.data.users[m.sender].money += Scommon * count
                        global.db.data.users[m.sender].common -= count * 1
                        conn.reply(m.chat, `Succes menjual ${count} Common Crate dengan harga ${Scommon * count} money`.trim(), m)
                    } else conn.reply(m.chat, `Common Crate kamu tidak cukup`.trim(), m)
                    break
                case 'uncommon':
                    if (global.db.data.users[m.sender].uncommon >= count * 1) {
                        global.db.data.users[m.sender].money += Suncommon * count
                        global.db.data.users[m.sender].uncommon -= count * 1
                        conn.reply(m.chat, `Succes menjual ${count} Uncommon Crate dengan harga ${Suncommon * count} money`.trim(), m)
                    } else conn.reply(m.chat, `Uncommon Crate kamu tidak cukup`.trim(), m)
                    break
                case 'mythic':
                    if (global.db.data.users[m.sender].mythic >= count * 1) {
                        global.db.data.users[m.sender].money += Smythic * count
                        global.db.data.users[m.sender].mythic -= count * 1
                        conn.reply(m.chat, `Succes menjual ${count} Mythic Crate dengan harga ${Smythic * count} money`.trim(), m)
                    } else conn.reply(m.chat, `Mythic Crate kamu tidak cukup`.trim(), m)
                    break
                case 'legendary':
                    if (global.db.data.users[m.sender].legendary >= count * 1) {
                        global.db.data.users[m.sender].money += Slegendary * count
                        global.db.data.users[m.sender].legendary -= count * 1
                        conn.reply(m.chat, `Succes menjual ${count} Legendary Crate dengan harga ${Slegendary * count} money`.trim(), m)
                    } else conn.reply(m.chat, `Legendary Crate kamu tidak cukup`.trim(), m)
                    break
                case 'sampah':
                    if (global.db.data.users[m.sender].sampah >= count * 1) {
                        global.db.data.users[m.sender].sampah -= count * 1
                        global.db.data.users[m.sender].money += Ssampah * count
                        conn.reply(m.chat, `Succes menjual ${count} sampah, dan anda mendapatkan ${Ssampah * count} money`.trim(), m)
                    } else conn.reply(m.chat, `Sampah anda tidak cukup`.trim(), m)
                    break
                    case 'kaleng':
                        if (global.db.data.users[m.sender].kaleng >= count * 1) {
                            global.db.data.users[m.sender].kaleng -= count * 1
                            global.db.data.users[m.sender].money += Skaleng * count
                            conn.reply(m.chat, `Succes menjual ${count} kaleng, dan anda mendapatkan ${Skaleng * count} money`, m)
                        } else conn.reply(m.chat, `Kaleng anda tidak cukup`, m)
                        break
                    case 'kardus':
                        if (global.db.data.users[m.sender].kardus >= count * 1) {
                            global.db.data.users[m.sender].kardus -= count * 1
                            global.db.data.users[m.sender].money += Skardus * count
                            conn.reply(m.chat, `Succes menjual ${count} kardus, dan anda mendapatkan ${Skardus * count} money`, m)
                        } else conn.reply(m.chat, `Kardus anda tidak cukup`, m)
                        break
                    case 'botol':
                        if (global.db.data.users[m.sender].botol >= count * 1) {
                            global.db.data.users[m.sender].botol -= count * 1
                            global.db.data.users[m.sender].money += Sbotol * count
                            conn.reply(m.chat, `Succes menjual ${count} botol, dan anda mendapatkan ${Sbotol * count} money`, m)
                        } else conn.reply(m.chat, `Botol anda tidak cukup`, m)
                        break
                    case 'kayu':
                        if (global.db.data.users[m.sender].kayu >= count * 1) {
                            global.db.data.users[m.sender].kayu -= count * 1
                            global.db.data.users[m.sender].money += Skayu * count
                            conn.reply(m.chat, `Succes menjual ${count} kayu, dan anda mendapatkan ${Skayu * count} money`, m)
                        } else conn.reply(m.chat, `Kayu anda tidak cukup`, m)
                        break
                    case 'pisang':
                        if (global.db.data.users[m.sender].pisang >= count * 1) {
                            global.db.data.users[m.sender].pisang -= count * 1
                            global.db.data.users[m.sender].money += Spisang * count
                            conn.reply(m.chat, `Succes menjual ${count} pisang, dan anda mendapatkan ${Spisang * count} money`, m)
                        } else conn.reply(m.chat, `Pisang anda tidak cukup`, m) 
                        break
                    case 'anggur':
                        if (global.db.data.users[m.sender].anggur >= count * 1) {
                            global.db.data.users[m.sender].anggur -= count * 1
                            global.db.data.users[m.sender].money += Sanggur * count
                            conn.reply(m.chat, `Succes menjual ${count} anggur, dan anda mendapatkan ${Sanggur * count} money`, m)
                        } else conn.reply(m.chat, `Anggur anda tidak cukup`, m)
                        break
                    case 'mangga':
                        if (global.db.data.users[m.sender].mangga >= count * 1) {
                            global.db.data.users[m.sender].mangga -= count * 1
                            global.db.data.users[m.sender].money += Smangga * count
                            conn.reply(m.chat, `Succes menjual ${count} mangga, dan anda mendapatkan ${Smangga * count} money`, m)
                        } else conn.reply(m.chat, `Mangga anda tidak cukup`, m)
                        break
                    case 'jeruk':
                        if (global.db.data.users[m.sender].jeruk >= count * 1) {
                            global.db.data.users[m.sender].jeruk -= count * 1
                            global.db.data.users[m.sender].money += Sjeruk * count
                            conn.reply(m.chat, `Succes menjual ${count} jeruk, dan anda mendapatkan ${Sjeruk * count} money`, m)
                        } else conn.reply(m.chat, `Jeruk anda tidak cukup`, m)
                        break
                    case 'apel':
                        if (global.db.data.users[m.sender].apel >= count * 1) {
                            global.db.data.users[m.sender].apel -= count * 1
                            global.db.data.users[m.sender].money += Sapel * count
                            conn.reply(m.chat, `Succes menjual ${count} apel, dan anda mendapatkan ${Sapel * count} money`, m)
                        } else conn.reply(m.chat, `Apel anda tidak cukup`, m)
                        break
                    case 'berlian':
                        if (global.db.data.users[m.sender].berlian >= count * 1) {
                            global.db.data.users[m.sender].berlian -= count * 1
                            global.db.data.users[m.sender].money += Sberlian * count
                            conn.reply(m.chat, `Succes menjual ${count} berlian, dan anda mendapatkan ${Sberlian * count} money`, m)
                        } else conn.reply(m.chat, `Berlian anda tidak cukup`, m)
                        break
                   case 'emas':
                        if (global.db.data.users[m.sender].emas >= count * 1) {
                            global.db.data.users[m.sender].emas -= count * 1
                            global.db.data.users[m.sender].money += Semasbiasa * count
                            conn.reply(m.chat, `Succes menjual ${count} emas, dan anda mendapatkan ${Semasbiasa * count} money`, m)
                        } else conn.reply(m.chat, `Emas anda tidak cukup`, m)
                        break
                    case 'pet':
                        if (global.db.data.users[m.sender].pet >= count * 1) {
                            global.db.data.users[m.sender].pet -= count * 1
                            global.db.data.users[m.sender].money += Spet * count
                            conn.reply(m.chat, `Succes menjual ${count} pet random, dan anda mendapatkan ${Spet * count} money`, m)
                        } else conn.reply(m.chat, `Pet Random anda tidak cukup`, m)
                        break 
                 case 'makananpet':
                        if (global.db.data.users[m.sender].makananpet >= count * 1) {
                            global.db.data.users[m.sender].makananpet -= count * 1
                            global.db.data.users[m.sender].money += Smakananpet * count
                            conn.reply(m.chat, `Succes menjual ${count} makanan pet, dan anda mendapatkan ${Smakananpet * count} money`, m)
                        } else conn.reply(m.chat, `Makanan pet anda tidak cukup`, m)
                        break 
                case 'makanannaga':
                        if (global.db.data.users[m.sender].makanannaga >= count * 1) {
                            global.db.data.users[m.sender].makanannaga -= count * 1
                            global.db.data.users[m.sender].money += Smakanannaga * count
                            conn.reply(m.chat, `Succes menjual ${count} makanan naga, dan anda mendapatkan ${Smakanannaga * count} money`, m)
                        } else conn.reply(m.chat, `Makanan naga anda tidak cukup`, m)
                        break
                 case 'makananphonix':
                        if (global.db.data.users[m.sender].makananphonix >= count * 1) {
                            global.db.data.users[m.sender].makananphonix -= count * 1
                            global.db.data.users[m.sender].money += Smakananphonix * count
                            conn.reply(m.chat, `Succes menjual ${count} makanan phonix, dan anda mendapatkan ${Smakananphonix * count} money`, m)
                        } else conn.reply(m.chat, `Makanan phonix anda tidak cukup`, m)
                        break
                    case 'makanankyubi':
                        if (global.db.data.users[m.sender].makanankyuni >= count * 1) {
                            global.db.data.users[m.sender].makanankyubi -= count * 1
                            global.db.data.users[m.sender].money += Smakanankyubi * count
                            conn.reply(m.chat, `Succes menjual ${count} makanan kyubi, dan anda mendapatkan ${Smakanankyubi* count} money`, m)
                        } else conn.reply(m.chat, `Makanan kyubi anda tidak cukup`, m)
                        break
                    case 'makanangriffin':
                        if (global.db.data.users[m.sender].makanangriffin >= count * 1) {
                            global.db.data.users[m.sender].makanangriffin -= count * 1
                            global.db.data.users[m.sender].money += Smakanangriffin * count
                            conn.reply(m.chat, `Succes menjual ${count} makanan griffin, dan anda mendapatkan ${Smakanangriffin * count} money`, m)
                        } else conn.reply(m.chat, `Makanan griffin anda tidak cukup`, m)
                        break
                    case 'makanancentaur':
                        if (global.db.data.users[m.sender].makanancentaur >= count * 1) {
                            global.db.data.users[m.sender].makanancentaur -= count * 1
                            global.db.data.users[m.sender].money += Smakanancentaur * count
                            conn.reply(m.chat, `Succes menjual ${count} makanan centaur, dan anda mendapatkan ${Smakanancentaur * count} money`, m)
                        } else conn.reply(m.chat, `Makanan centaur anda tidak cukup`, m)
                        break
                    case 'aqua':
                        if (global.db.data.users[m.sender].aqua >= count * 1) {
                            global.db.data.users[m.sender].aqua -= count * 1
                            global.db.data.users[m.sender].money += Saqua * count
                            conn.reply(m.chat, `Succes menjual ${count} aqua, dan anda mendapatkan ${Saqua * count} money`, m)
                        } else conn.reply(m.chat, `Aqua anda tidak cukup`, m)
                        break
                    case 'iron':
                        if (global.db.data.users[m.sender].iron >= count * 1) {
                            global.db.data.users[m.sender].iron -= count * 1
                            global.db.data.users[m.sender].money += Siron * count
                            conn.reply(m.chat, `Succes menjual ${count} pancingan, dan anda mendapatkan ${Siron * count} money`, m)
                        } else conn.reply(m.chat, `Iron anda tidak cukup`, m)
                        break
                    case 'string':
                        if (global.db.data.users[m.sender].string >= count * 1) {
                            global.db.data.users[m.sender].string -= count * 1
                            global.db.data.users[m.sender].money += Sstring * count
                            conn.reply(m.chat, `Succes menjual ${count} string, dan anda mendapatkan ${Sstring * count} money`, m)
                        } else conn.reply(m.chat, `String anda tidak cukup`, m)
                        break
                    case 'batu':
                        if (global.db.data.users[m.sender].batu >= count * 1) {
                            global.db.data.users[m.sender].batu -= count * 1
                            global.db.data.users[m.sender].money += Sbatu * count
                            conn.reply(m.chat, `Succes menjual ${count} batu, dan anda mendapatkan ${Sbatu * count} money`, m)
                        } else conn.reply(m.chat, `Batu anda tidak cukup`, m)
                        break
                    case 'limit':
                        if (global.db.data.users[m.sender].limit >= count * 1) {
                            global.db.data.users[m.sender].limit -= count * 1
                            global.db.data.users[m.sender].money += Slimit * count
                            conn.reply(m.chat, `Succes menjual ${count} limit, dan anda mendapatkan ${Slimit * count} money`, m)
                        } else conn.reply(m.chat, `Limit anda tidak cukup`, m)
                        break
                    case 'diamond':
                       if (global.db.data.users[m.sender].diamond >= count * 1) {
                           global.db.data.users[m.sender].diamond -= count * 1
                           global.db.data.users[m.sender].money += Sdiamond * count
                           conn.reply(m.chat, `Succes menjual ${count} Diamond, dan anda mendapatkan ${Sdiamond * count} money`, m)
                        } else conn.reply(m.chat, `Diamond anda tidak cukup`, m)
                       break
                default:
                    return conn.reply(m.chat, Kchat, flok)
            }
        }
    } catch (e) {
        conn.reply(m.chat, Kchat, flok)
        console.log(e)
    }
}

handler.help = ['shop <sell|buy> <args>']
handler.tags = ['rpg']
    
handler.command = /^(shop)$/i
handler.limit = false
handler.group = true
export default handler
