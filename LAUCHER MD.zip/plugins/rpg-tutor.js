/**
@credit RijalGanzz
@Furina Md
@Whatsapp Me
wa.me/62882009507703
**/
let handler = async (m) => {

let anu =`
╭╾• 〔 TUTORIAL  〕
│ 
├〘 Tutorial EPIC RPG 〙
├⛶ *乂claim*
│   Staterpack yang bisa di klaim 
│   12 jam sekali
├⛶ *乂mulung*
├⛶ *乂adventure*
├⛶ *乂petualang*
│   Untuk mencari resource seperti 
│   Money, Exp, dll..,dibutuhkan  
│   minimal 80 nyawa untuk bisa 
│   melakukannya dan, kamu tidak 
│   dapat spam karena ada delay 5 
│   menit
├⛶ *乂use potion <jumlah>*
│   Untuk memakai potion/untuk 
│   mengisi nyawa/health
├⛶ *乂shop buy potion <jumlah>*
│   Untuk membeli potion dan ketik 
├⛶ *乂use potion <jumlah>*
│   untuk menggunakan potion
├⛶ *乂shop <args>*
│   Untuk membeli atau menjual sesuatu
├⛶ *乂shop buy <crate> <jumlah>*
│   Untuk membeli Crate
├⛶ *乂profile*
├⛶ *乂pp*
├⛶ *乂profil*
│   untuk mengetahui No whatsapmu, dll
├⛶ *乂inv*
├⛶ *乂inventory*
├⛶ *乂bal*
│   Untuk mengecek nyawa, money, dll.
├⛶ *乂judi <jumlah>*
│   *_Jangan judi, Karena gk bakal_*
│   *_balik modal.BENERAN GK BOHONG_*
│  
└─「 *E L A I N A  R P G* 」


`
await m.reply(anu)
}

handler.help = ["tutorialrpg"];
handler.tags = ["main"];
handler.command = /^(tutorialrpg|tutorpg)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;

handler.admin = false;
handler.botAdmin = false;

handler.fail = null;

export default handler
